// ==UserScript==
// @name           Next Link
// @namespace      localhost
// @description    在页面底部添加下一页连接

function GetUrlPara(ParaStr) {
	var value = "";
	var UrlParas = location.search.replace("?", "").split("&");
	var UrlParas_Lenght = UrlParas.length;
	for (var i = 0; i < UrlParas_Lenght; i++) {
		var UrlPara = UrlParas[i];
		var Para = UrlPara.split("=");
		if (Para[0] === ParaStr) {
			if (value != "") {
				value += ",";
			}
			value += Para[1];
		}
	}
	return value;
}
function replaceUrlPara(ParaStr, value) {
	var currentId = GetUrlPara("id");
	var UrlParas = location.href;
	if (UrlParas.indexOf("&1=1") === -1) {
		UrlParas = location.href + "&1=1";
	}
	var newUrl = UrlParas.replace(ParaStr + "=" + currentId + "&", ParaStr + "=" + value + "&");
	return newUrl;
}
function AddNextLink() {
	var currentId = GetUrlPara("id");
	if (currentId === "")
		return;
	var nextId = currentId / 1 + 1;
	var NextLinkUrl = replaceUrlPara("id", nextId);
	var AddLink = document.createElement('a');
	AddLink.className = 'next';
	AddLink.href = NextLinkUrl;
	AddLink.text = "下一页";
	document.body.appendChild(AddLink);
	
	var AddLink_style = ".next{display: block; text-align: center; font-size: 20px;}body{text-align: center;}";
	var style = document.createElement('style');
	style.type = 'text/css';
	style.textContent = AddLink_style;
	document.body.appendChild(style);
	
}

function AddNextLink() {
	var adrr = location.href.split('?');
	if (adrr.length >= 2){
		var adr = adrr[1];
		var re = adr.match(/\d+/g);
		if (re) {
			re = re[re.length - 1];
			reNext = (parseInt(re, 10) + 1) + '';
			while (reNext.length < re.length) {
				reNext = '0' + reNext;
			};
			j = adr.lastIndexOf(re);
			adreNext = adr.substring(0, j) + adr.substring(j, adr.length).replace(re, reNext);
			var nextLink = document.createElement('a');
			nextLink.href = adreNext;
			nextLink.setAttribute("style", "bottom:10px;left: 52%;position: fixed;");
			nextLink.text = "下一页";
			document.body.appendChild(nextLink);
			
			reBefore = (parseInt(re, 10) - 1) + '';
			while (reBefore.length < re.length) {
				reBefore = '0' + reBefore;
			};
			j = adr.lastIndexOf(re);
			adrBefore = adr.substring(0, j) + adr.substring(j, adr.length).replace(re, reBefore);
			var nextLink = document.createElement('a');
			nextLink.href = adrBefore;
			nextLink.setAttribute("style", "bottom:10px;left: 48%;position: fixed;");
			nextLink.text = "上一页";
			document.body.appendChild(nextLink);
		} else {
			return;
		}
	}
}

document.addEventListener('DOMContentLoaded', AddNextLink, false);

// mediaWrap for opera
// http://my.opera.com/ezibo
// just place the js in the profile/script folder ֻҪ����scriptĿ¼�¼���
// Guide for scripting:
// another function for gather media information:
// in your menu.ini add a item as
//Item, "Show All Media(&G)" = Go to page, "javascript:showAllMedia();", , ,"Attachment Video"
//Item, "��ʾ����ý��(&G)" = Go to page, "javascript:showAllMedia();", , ,"Attachment Video"

var mediaUrls = "";

function getClassidType(obj) {
  if (obj.getAttribute("classid")) {
    switch (obj.getAttribute("classid").toLowerCase()) {
      case "clsid:05589fa1-c356-11ce-bf01-00aa0055595a":  // wmp6
      case "clsid:22d6f312-b0f6-11d0-94ab-0080c74c7e95":  // wmp6.4
      case "clsid:6bf52a52-394a-11d3-b153-00c04f79faa6":  // wmp7&9&10
        return "application/x-mplayer2";
      case "clsid:cfcdaa03-8be4-11cf-b84b-0020afbbccfa":  // real player
        return "audio/x-pn-realaudio-plugin";
      case "clsid:02bf25d5-8c17-4b23-bc80-d3488abddc6b":  // quicktime player
        return "video/quicktime";
      case "clsid:d27cdb6e-ae6d-11cf-96b8-444553540000":  // shockwave flash player
        return "application/x-shockwave-flash";
      case "clsid:166b1bca-3f9c-11cf-8075-444553540000":  // shockwave Director player
        return "application/x-director";
    }
  }
  return "";
}

function getAbsoluteUrl(url,srcDocument){
  var endurl = "";
  if(url=="") {
    return "";
  }
  else if ((url.toLowerCase().indexOf("http://")==0)
    ||(url.toLowerCase().indexOf("rtsp://")==0)
    ||(url.toLowerCase().indexOf("mms://")==0)
   )
    endurl=url;
  else{
    var pageurl;
    var hostname=srcDocument.location.hostname;
    var pathname=srcDocument.location.pathname;
    var portname=srcDocument.location.port;

    if(portname.length==0){
      pageurl="http://"+hostname+pathname;
    }
    else{
      pageurl="http://"+hostname+":"+portname+pathname;
    }
    var pagepath=pageurl.substring(0,pageurl.lastIndexOf("/")+1);
    if(url.charAt(0)!="." && url.charAt(0)!="/")
      endurl=pagepath+url;
    else if(url.charAt(0)=="/")
      endurl="http://"+hostname+url;
    else{
      if(url.charAt(0)=="."){
        endurl=pagepath;
        while(url.charAt(0)=="."){
          url=url.substr(3);
          endurl=endurl.substring(0,endurl.length-1);
            endurl=endurl.substring(0,endurl.lastIndexOf("/")+1);
          }
        endurl=endurl+url;
      }
    }
  }
  return(endurl);
}

function frameGetMediaUrl(doc){
  getAllMedia(doc);
  if(doc.frames.length>0){
    for(var i=0;i<doc.frames.length;i++){
      try{
        var f=doc.frames[i].document;
        frameGetMediaUrl(f);
      }
      catch(e){continue;}
    }
  }
}

function getAllMedia(doc){
  var oe=doc.getElementsByTagName('embed');
  for(var i=0;i<oe.length;i++){
    var mu=getAbsoluteUrl(oe[i].getAttribute('src'),doc);
    mediaUrls = mediaUrls + oe[i].outerHTML + "<br><a href='" + mu + "'>" + mu + "</a><br>"
  }
  return;
}

function showAllMedia(){
  mediaUrls = "";
  frameGetMediaUrl(document);
  var w=window.open(' ');
  w.document.write(mediaUrls);
  eval();
}

function procMediaObject(doc){

  var oc=doc.getElementsByTagName('OBJECT');
  //real start
  var realIndexArray = new Array();
  var realConsole = "";
  var realConsoleArray = new Array();
  var realSrc = "";
  var realSrcArray = new Array();
  var rci = 0;
  //real end
  if (oc!=null&&oc.length>0) {
    for(var i=0;i<oc.length;i++){
      try{
        var w,h,s,mt,sty;
        var wmp="";
        var b_showstatusbar = false;
        var b_enablecontextmenu = false;
        var b_autostart = false;
        var pName, value,ps="";
        var rc="";
        mt=getClassidType(oc[i]);
        var params=oc[i].getElementsByTagName("param");
        for (var p=0;p<params.length;p++) {
          pName = params[p].getAttribute("name");
          value = params[p].getAttribute("value");
          if(!pName || !value) continue;
          pName = pName.toLowerCase();
          switch(pName){
            case "src":
            case "filename":
            case "url":
            case "movie":
              s=value;break;
            case "autostart":
              b_autostart = true;
              if(value=="true" ||value=="1" ||value=="-1") ps+=" autostart='true'";
              else ps+=" autostart='0'";
              break;
            case "showstatusbar":
              b_showstatusbar = true;
              ps+=" showstatusbar='1'";
              break;
            case "enablecontextmenu":
              b_enablecontextmenu = true;
              ps+=" enablecontextmenu='1'";
              break;
            case "loop":
              if(value=="true" ||value=="1") ps+=" loop='1'";
              else ps+=" loop='0'";
              break;
            case "console":
              rc=value;
              ps+=" " + pName + "='" + value + "'";
              break;
            default:
              ps+=" " + pName + "='" + value + "'";
              break;
          }
        }
        //for wmp only
        if(mt=="application/x-mplayer2") {
          if(!b_showstatusbar) wmp = " showstatusbar='1'";
          if(!b_enablecontextmenu) wmp += " enablecontextmenu='1'";
          if(!b_autostart) wmp += " autostart='1'";
        }

        //style,width,height
        sty=oc[i].getAttribute('style');
        if(sty!=null&&sty.length > 0) {
          sty = " style='" + sty + "'";
          w="";
          h="";
        }
        else {
          sty="";
          w=oc[i].getAttribute('width');
          h=oc[i].getAttribute('height');
          w=(w>0||(w!=null && w.indexOf("%")>0))?" width='"+w+"'":" width='300'";
          h=(h>0||(h!=null && h.indexOf("%")>0))?" height='"+h+"'":" height='200'";
        }
        //flash can't set Absolute Url
        if(!s) s = "";
        if(mt != "application/x-shockwave-flash") {
          s = getAbsoluteUrl(s,doc);
        }
				//real start
        if(mt=="audio/x-pn-realaudio-plugin"  && rc.length > 0) {
          if (rc !=  realConsole) {
            realConsole = rc;
            realIndexArray[rci] = i.toString();
            realConsoleArray[rci] = rc;
            realSrcArray[rci] = s;
            rci++;
          }
          else {
            realIndexArray[rci-1] = realIndexArray[rci-1] + "," + i.toString();
          }
        }
        //real end
        try {
					var em=oc[i].getElementsByTagName("embed");
					if (mt=="") {
						mt= em[0].getAttribute('type');
						if (mt!=null&&mt.length>0) {
							mt = "type=" + mt;
						}
					}
					else {
						mt = "type=" + mt;
					}
          var eih="<embed " + mt + sty + wmp + w + h + ps + " src='" + s + "'></embed>";
          em[0].outerHTML = eih;
          var ih = oc[i].innerHTML;
          oc[i].innerHTML = ih;
        }
        catch(e){
					var eih="<embed " + mt + sty + wmp + w + h + ps + " src='" + s + "'></embed>";
          oc[i].innerHTML=oc[i].innerHTML+eih;
        }
      }
      catch(ex){
        continue;
      }
    }
  }
  var ed = doc.getElementsByTagName('EMBED');
  for(var i=0;i<ed.length;i++){
    ed[i].setAttribute('autostart','1');
    var t = ed[i].getAttribute('type');
    if (t!=null) {
      if (t.toLowerCase().indexOf("oleobject")>-1) {
        var codebase = ed[i].getAttribute('codebase');
        if(codebase != null && codebase.indexOf("http://activex.microsoft.com/activex/controls/mplayer") > -1 ) {
          ed[i].setAttribute('type','application/x-mplayer2');
          var oh = ed[i].outerHTML;
          ed[i].outerHTML = oh;
        }
        else {
          ed[i].setAttribute('type','application/x-meadco-neptune-ax');
          var oh = ed[i].outerHTML;
          ed[i].outerHTML = oh;
        }
      }
      else if(t.toLowerCase().indexOf("application/x-mplayer2")>-1) {
        ed[i].setAttribute('showstatusbar','1');
        ed[i].setAttribute('enablecontextmenu','1');
        var oh = ed[i].outerHTML;
        ed[i].outerHTML = oh;
      }
      else if(t.toLowerCase().indexOf("audio/mpeg")>-1) {
        ed[i].setAttribute('type','application/x-mplayer2');
        ed[i].setAttribute('showstatusbar','1');
        ed[i].setAttribute('enablecontextmenu','1');
        var oh = ed[i].outerHTML;
        ed[i].outerHTML = oh;
      }
    }
    else {
      var filesrc = ed[i].getAttribute('src');
      var li = filesrc.lastIndexOf('.')+1;
      var ft="";
      if (li > 0) {
        ft = filesrc.substr(li).toLowerCase();
      }
      if(ft=="wma"||ft=="mp3"||ft=="wmv"||ft=="mpg"||ft=="avi"||ft=="asf"){
        ed[i].setAttribute('type','application/x-mplayer2');
        ed[i].setAttribute('showstatusbar','1');
        ed[i].setAttribute('enablecontextmenu','1');
        var oh = ed[i].outerHTML;
        ed[i].outerHTML = oh;
      }
    }
  }
}

//����������
if(!((location.href.indexOf('220.181.27.54') >-1 )
     ||(location.href.indexOf('56.com') >-1 )
     ||(location.href.indexOf('youtube.com') >-1 )
  ))
{
document.addEventListener('load',function (e) {procMediaObject(document);},false);
}
//document.addEventListener('AfterScript', function (e) {alert(111);procMediaObject(document);},false);
//document.addEventListener('AfterExternalScript', function (e) {alert(222);procMediaObject(document);},false);
//javascript:showAllMedia(document);
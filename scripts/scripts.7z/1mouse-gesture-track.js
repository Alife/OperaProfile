﻿// ==UserScript==
// @name Mouse Gesture Track
// @author somh
// @ahmore@gmail.com
// @ujs:modified 16:13 2007-10-13
// ==/UserScript==

(function(){
	function mPos(ev){
		if(ev.pageX || ev.pageY){return {x:ev.pageX, y:ev.pageY};}
		return {
			x:ev.clientX + document.body.scrollLeft - document.body.clientLeft,
			y:ev.clientY + document.body.scrollTop - document.body.clientTop
		};
	}
	function mouseMove(ev){
			ev = ev || window.event;
			var pos = mPos(ev);
			if(rite){
				var dot=document.createElement('div');
				dot.style='position:absolute;z-index:10000;margin-left:-3px;margin-top:-3px;top:'+pos.y+'px;left:'+pos.x+'px;content:"✲";font-size:15px !important;';
dot.style.color="RGB("+Math.floor(Math.random()*200)+"%,"+Math.floor(Math.random()*150)+"%,"+Math.floor(Math.random()*100)+"%)";
				dot.className='mousetrack';
				document.body.appendChild(dot);
			}
	}
	function cleanTrack(){
		rite=0;var es=document.getElementsByTagName('div');
		for(var i=0;i<es.length;i++){if(es[i].className=='mousetrack'){es[i].parentNode.removeChild(es[i]);i--;}}
	}
	var rite=0;
	opera.addEventListener('BeforeEvent.mousedown',function(ev){ev=ev.event;if(ev.which==3){rite=1;setTimeout(function(){cleanTrack() ;},1000);}else{cleanTrack();}},false)
	opera.addEventListener('BeforeEvent.mouseup',function(){cleanTrack();},true)
	window.addEventListener('mousemove',mouseMove, false);
})()


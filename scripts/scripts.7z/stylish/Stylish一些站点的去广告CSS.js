// ==UserScript==
// @name stylish
// @author ezibo
// @version 1.0 
// @mod by NLF 2010 01 25
// @exclude file://*
// ==/UserScript==
 window.StylishSiteDefine.push(
{"name": "驱动之家",
	"enabled": true,
	"url_rgexp": /mydrivers\.com/i,
	"url_example": "www.mydrivers.com",
	"created_by": "NLF",
	"created_at": "2010-1-15",
	"updated_at": "2009-1-15",
	"data": [
					'body\
				{background-color:white}\
					body>div:nth-of-type(1),\
					body>div.top+div.hang1>.left2,\
					div[class*="gg"],\
					div[align="center"],\
					table[width="100%"][height="210"],\
					DIV[id^="ad_"],\
					div[id^="sidebar"],\
					td[width="634"]>table[width="100%"][height="70"],\
					body>table:nth-child(22)>tbody>tr>td:last-child\
					{\
						display:none !important;\
					}\
					body>div.top+div.hang1>.right2 li\
					{\
						padding-left:12px !important;\
						padding-right:8px !important;\
						float:left !important;\
					}\
					body>div.top+div.hang1>.right2,\
					body>div.top+div.hang1>.right2>*\
					{\
						padding:0px !important;\
						width:auto !important;\
						height:auto!important;\
						text-align:left !important;\
					}\
					body>div.top+div.hang1>.right2>*\
					{\
					padding-left:10px !important;\
					}\
					.top>div[class^=search]\
					{\
						float:right!important;\
						clear:right!important;\
					}\
					div.cyqdnr\
					{\
						height:316px!important;\
						overflow:hidden!important;\
					}\
					div.rdhtnr\
					{\
						height:251px!important;\
					}',
	]
},

{"name": "中关村在线",
	"enabled": true,
	"url_rgexp": /zol\.com/i,
	"url_example": "zol.com.cn",
	"created_by": "NLF",
	"created_at": "2010-1-15",
	"updated_at": "2009-1-15",
	"data": [
						'div.banner960,\
						ul[class*="word_ad"],\
						#detailScrollPromoInfo #rollnews,\
						DIV[class="Adl"],\
						.adSpace,\
						*[id*="Float"],\
						*[class*="_ad"],\
						*[id*="_ad"],\
						*[id^="ad_"],\
						*[class^="Adr"],\
						*[id*="AD"],\
						*[id*="Bar"],\
						body>div.nav+div[class*="wrapper"] *,\
						body>div.nav+div[class*="wrapper"]+div\
					{\
						display:none !important;\
					}\
					body>div.nav+div[class*="wrapper"]\
				{\
					height:192px!important;\
				}'
	]
},
{"name": "纳米下载页",
	"enabled": true,
	"url_rgexp": /d\.namipan\.com\/d/i,
	"url_example": "d.namipan.com/d",
	"created_by": "NLF",
	"created_at": "2010-1-15",
	"updated_at": "2009-1-15",
	"data": [
						'div[class*="ad_"],\
						#header+div>iframe,\
						.left>.body>.info>.info_r\
					{display:None !important;}\
						.left>.body>.info>.info_l\
					{float:none!important;width:auto!important;}\
						.left>.body>.info>.info_l>.info_1_1,\
						.left>.body>.info>.info_l>.info_1_1>div\
					{width:640px !important;}'
	]
},
{"name": "rayfile下载页",
	"enabled": true,
	"url_rgexp": /www\.rayfile\.com\/.*\/files/i,
	"url_example": "www.rayfile.com/zh-cn/files",
	"created_by": "NLF",
	"created_at": "2010-1-15",
	"updated_at": "2009-1-15",
	"data": [
						'#frmmask,\
						#frmDialog,\
						#frmDialog,\
						#frmDyn,#nDown_left,\
						#nDown_level_2,\
						#content>div[class="nDown_level_0"],\
						div[style="float:left"],\
						#ad_txt,div[class*="TXTAD"],\
						#M1-AD\
					{display:none!important;}\
						#nDown_right,\
						#divinfo_1,#divinfo_1>*,\
						#ndFileinfo,#ndFileinfo>*\
					{float:none !important;width:auto !important;}\
						#textfield\
					{width:500px !important;}'
	]
},
{"name": "照片处理网",
	"enabled": true,
	"url_rgexp": /www\.photops\.com/i,
	"url_example": "www.photops.com",
	"created_by": "NLF",
	"created_at": "2010-1-15",
	"updated_at": "2009-1-15",
	"data": [
							'div[id="main_l"]>div:nth-child(4),\
							div[id="main_l"]>div:nth-child(5),\
							div[id="main_l"]>div:nth-child(6)\
						{display:none !important;}'
	]
},
{"name": "思源论坛",
	"enabled": true,
	"url_rgexp": /www\.missyuan\.com/i,
	"url_example": "www.missyuan.com",
	"created_by": "NLF",
	"created_at": "2010-1-15",
	"updated_at": "2009-1-15",
	"data": [
						'div[class="spaceborder"],\
						div[align="left"],\
						div[align="center"],\
						table[id="table1"]\
					{display:none !important;}'
	]
},
{"name": "软件之家",
	"enabled": true,
	"url_rgexp": /myfiles\.com\.cn/i,
	"url_example": "myfiles.com.cn",
	"created_by": "NLF",
	"created_at": "2010-1-16",
	"updated_at": "2009-1-16",
	"data": [
							'body>table[width="923"]:nth-child(5),\
							body>table[width="923"]:nth-child(6),\
							body>table[width="923"]:nth-child(7),\
							body>table[width="923"]:nth-child(8),\
							body>table[width="923"]:nth-child(9),\
							div[align="center"],\
							body>table[width="923"]:nth-child(12)>tbody>tr>td:nth-child(2)>table:nth-child(4)>tbody>tr>td>table:nth-child(7)>tbody>tr:nth-child(2)>td>table[width="100%"],\
							BODY > TABLE[width="923"]:nth-child(10) > TBODY > TR > TD:nth-child(2) > TABLE:nth-child(4) > TBODY > TR > TD:nth-child(1) > TABLE:nth-child(7) > TBODY > TR:nth-child(2) > TD > TABLE[width="100%"]\
						{display:none !important;}'
	]
},
{"name": "六房间",
	"enabled": true,
	"url_rgexp": /6\.cn/i,
	"url_example": "6.cn",
	"created_by": "NLF",
	"created_at": "2010-1-26",
	"updated_at": "2009-1-26",
	"data": [
					'div[class="listTextAd"],\
					div[id="channelTextAd"],\
					div[id="idxPopularize"],\
					div#palyerAdText,\
					#watch>div[class="column3"],\
					*[id^="adText"],\
					div[id^="ays"],\
					div[class="column1"]>div[class^="spacing"]\
				{display:None !important;}\
					div[class="column2"]\
				{float:right !important;}\
					#watch\
				{width:820px !important;margin-left:auto !important;margin-right:auto !important;}'
	]
},

{"name": "酷6视频",
	"enabled": true,
	"url_rgexp": /ku6\.com/i,
	"url_example": "ku6.com",
	"created_by": "NLF",
	"created_at": "2010-1-26",
	"updated_at": "2009-1-26",
	"data": [
				'div[id="swfdiv"],\
				*[id*="ad_"],\
				div[class="wd675"]>div[class^="banner"],\
				div[class*="adv"],\
				img[class="b_ad"],\
				div[id="indexplayer2"],\
				div[id^="gg"],\
			{display:none !important;}\
				body>div[class="area content cfix"]\
			{width:1080px !important;}\
				body>div[class="area content cfix"]>.areaLeft\
			{width:700px !important;}\
				div[class="videoPlay"],\
				#playerModule>#video_player,\
				.areaLeft>.videoBtn\
			{width:700px !important;}\
			body\
			{background-image:none!important;}'
	]
},

{"name": "中国教程网",
	"enabled": true,
	"url_rgexp": /jcwcn\.com/i,
	"url_example": "jcwcn.com",
	"created_by": "NLF",
	"created_at": "2010-1-26",
	"updated_at": "2009-1-26",
	"data": [
				'DIV[class^="ad1"],\
				DIV[id^="ad1"],\
				div[class="gadspro"],\
				body>div[class="main"]>div[class="main_center"]\
			{display:none !important;}'
	]
},
{"name": "狗狗下载页",
	"enabled": true,
	"url_rgexp": /119\.147\.41\.16\/down/i,
	"url_example": "119.147.41.16/down",
	"created_by": "NLF",
	"created_at": "2010-1-26",
	"updated_at": "2009-2-2",
	"data": [
				'.ggSideBox,\
				.commentBox+p\
			{display:None!important;}\
				.ggContent,\
				.downBox,\
				.downBox *\
			{width:auto!important;}\
				.commentBox\
			{\
			float:right!important;\
			width:auto!important;\
			}'
	]
},
{"name": "新浪",
	"enabled": true,
	"url_rgexp": /sina\.com\.cn/i,
	"url_example": "http://www.sina.com.cn/",
	"created_by": "NLF",
	"created_at": "2010-1-26",
	"updated_at": "2009-2-6",
	"data": ['\
				*[id*="GoogleAd"],\
				*[id*="PublicRelation"],\
				*[id^="divname"],\
				*[class*="ads"],\
				*[class*="AD"],\
				#CoupletMediaWrap,\
				*[class*="ads_"],\
				*[id*=_container_div_],\
				*[id*=flashcontent_],\
				*[id*=ad_],\
				.topads,\
				#crWrap,\
				#clWrap,\
				*[class*="AD"],\
				#bgAdWrap,\
				#page>.Main>.sidebar,\
				.Main>div[class*="Container"]:nth-child(1)>div:nth-child(n+2)\
			{\
				display:none!important;\
			}\
				.Main>div[class*="Container"],\
				.Main>div[class*="Container"]>div:nth-child(1)>div:nth-child(1)\
			{\
				float:none!important;\
				width:auto!important;\
			}'
	]
},
{"name": "网易",
	"enabled": true,
	"url_rgexp": /163\.com/i,
	"url_example": "http://www.163.com/",
	"created_by": "NLF",
	"created_at": "2010-2-22",
	"updated_at": "2009-2-22",
	"data": ['\
				script[src*="duilian.js"],\
				*[class^="gg"],\
				*[class^="ad"],\
				div[id="cRn1"][class="tab ui_conR"],\
				#flashad,\
				div.endArea>div.colR\
			{\
				display:none!important;\
			}\
				div.endArea>div.colL,\
				div.endArea>div.colL *:not(object)\
			{\
				\
			}\
				div[class*="bg_endPage"]\
			{\
				background-image:none!important;\
				background-color:#F7FCFF!important;\
				border-left:1px solid #ccc!important;\
				border-right:1px solid #ccc!important;\
			}'
	]
},
{"name": "搜狐",
	"enabled": true,
	"url_rgexp": /sohu\.com/i,
	"url_example": "http://www.souhu.com/",
	"created_by": "NLF",
	"created_at": "2010-2-22",
	"updated_at": "2009-2-22",
	"data": ['\
				div[class*="sogouService"],\
				*[id*="AD"],\
				*[class*="ad"],\
				*[id^="#ad_"],\
				*[id*="BOOKTURN"],\
				*[id*="_FLOAT"],\
				*[id^="COUPLET"],\
				*[id^="ad_"]\
			{\
				display:none !important;\
			}'
	]
},
{"name": "凤凰网",
	"enabled": true,
	"url_rgexp": /ifeng\.com/i,
	"url_example": "http://www.ifeng.com/",
	"created_by": "NLF",
	"created_at": "2010-2-22",
	"updated_at": "2009-2-22",
	"data": ['\
				#main>#main_right,\
				.areaAd\
			{\
				display:none !important;\
			}'
	]
},
{"name": "电脑之家",
	"enabled": true,
	"url_rgexp": /pchome\.net/i,
	"url_example": "http://www.pchome.net/",
	"created_by": "NLF",
	"created_at": "2010-2-25",
	"updated_at": "2009-2-25",
	"data": ['div[id^="Bar"],\
				ul[class^="adv"],\
				div[class*="-ad"],\
				div[id*="-ad"],\
				div[id^="AD"],\
				div[class*="downloadAd"],\
				div[class^="ad"]\
			{\
				display:none!important;\
			}'
	]
}
);

// ==UserScript==
// @name stylish
// @author ezibo
// @version 1.0
// @description site define css content
// @ujs:category browser: enhancements
// @ujs:published 2009-04-02
// @ujs:modified 2009-04-02
//
// Add URLs to exclude here:
// @exclude file://*
//
// ==/UserScript==

(function() {
	var DebugMode = window.DebugMode;
	var adr = location.href;
	SiteDefine = window.StylishSiteDefine || [];
	delete window.DebugMode;
	delete window.StylishSiteDefine;
	var data;
	var CssContent = "";
	var CssLink = "";

	for (var i = 0, Site = ""; Site = SiteDefine[i]; i++) {
		if (adr.match(Site.url_rgexp) && (Site.enabled.toLowerCase() == "true")) {
			data = Site.data;
			CssLink = Site.css_src;
			for (var n in data) CssContent += data[n] + '\n';
			break;
		}
	}
	if (CssContent.length == 0) {
		return;
	}
	else {
		log(adr + '\n' + CssContent);
		try {
			var node = document.body || document.getElementsByTagName('head')[0];
			if (node) {
				var style = document.createElement('style');
				style.type = 'text/css';
				style.textContent = CssContent;
				node.appendChild(style);
			}
			else {
				document.write('<style type="text/css">' + CssContent + '</style>');
			}
		}
		catch (e) {
			log(e);
		}
	}

	//	if (CssLink && CssLink != "") {
	//		log(adr + '\n' + CssLink);
	//		try {
	//			var node = document.body || document.getElementsByTagName('head')[0];
	//			if (node) {
	//				var style = document.createElement('link');
	//				style.type = 'text/css';
	//				style.rel = 'stylesheet';
	//				style.href = CssLink;
	//				node.appendChild(style);
	//			}
	//			else {
	//				document.write('<link type="text/css" href="' + CssLink + '" rel="stylesheet" />');
	//			}
	//		}
	//		catch (e) {
	//			log(e);
	//		}
	//	}

	function log(message) {
		if (DebugMode) {
			if (window.opera) {
				opera.postError(message);
			}
			else if (window.console) {
				console.log(message);
			}
		}
	}
})();


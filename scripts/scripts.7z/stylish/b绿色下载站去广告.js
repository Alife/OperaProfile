﻿ window.StylishSiteDefine.push(
{ "name": "greendown",
	"enabled": "true",
	"url_rgexp": /\.greendown\.cn/,
	"url_example": "www.greendown.cn",
	"data": [
	'div[class*="ad-"],.col1,.brand{display:none !important; }',
	'.software-view{margin:0 auto !important;float:none !important; }'
	]
}
);

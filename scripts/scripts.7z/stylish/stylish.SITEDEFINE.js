﻿ window.StylishSiteDefine.push(
{"name": "feiku",
	"enabled": "true",
	"url_rgexp": /feiku\.com\/html/i,
	"url_example": "http://www2.feiku.com/html//book/130/152703/4126004.shtm",
	"updated_at": "2009-04-04",
	"created_by": "ezibo",
	"created_at": "2009-04-04",
	"data": [
	'fieldset{display: none !important;}',
	'div[id="End"]{display: none !important;}',
	'A[href*="http://www.51.la/"]{display: none !important;}',
	'HTML > BODY > CENTER:nth-child(5) > DIV[id="Ws"] > DIV[id="Top"] > DIV[id="Content"]:nth-child(5) > DIV:nth-child(4){ display: none !important }'
	]
},
{ "name": "greendown",
	"enabled": "true",
	"url_rgexp": /\.greendown\.cn/,
	"url_example": "www.greendown.cn",
	"data": [
	'div[class*="ad-"],.col1,.brand{display:none !important; }'
	]
},
{"name": "yahoomail",
	"enabled": "true",
	"url_rgexp": /mail\.yahoo\.com/,
	"url_example": "mail.yahoo.com",
	"css_src": "user.css",
	"data": [
	'#northbanner,#ygmauser fieldset a,#rads,#SW2,#SW3,#SW4,.separator,#MNW{display: none !important;}',
	'#compose_editorArea{width:95% !important;min-height:500px !important}'
	]
},
{"name": "operachina",
	"enabled": "true",
	"url_rgexp": /bbs\.operachina\.com/,
	"url_example": "http://bbs.operachina.com/",
	"data": [
	'DIV[class=container]{display: none !important;}',
	'.forumlist:hover{border-left:none !important;margin:0 !important;padding-left:7px !important}',
	'.page-body>panel,.operachinacom .navbar,.operachinacom #page-footer{display:none !important}',
	'.newrow:hover{border-left:none !important;margin-left:5px;padding:5px 5px 10px 19px !important}'
	]
},
{"name": "gougoucom",
	"enabled": "true",
	"url_rgexp": /www\.gougou\.com/,
	"url_example": "http://www.gougou.com/",
	"data": [
	'.ggAD, .ggRelate{display:none !important;}'
	]
},
{"name": "twittercom",
	"enabled": "true",
	"url_rgexp": /twitter\.com/,
	"url_example": "http://twitter.com/",
	"data": [
	'.wrapper{opacity:0.75}'
	]
},
{"name": "feiku",
	"enabled": "true",
	"url_rgexp": "www.feiku.com",
	"url_example": "http://www.feiku.com/",
	"updated_at": "2009-04-04",
	"created_by": "ezibo",
	"created_at": "2009-04-04",
	"data": [
	'DIV[class=container]{display: none !important;}'
	]
},
{"name": "67",
	"enabled": "true",
	"url_rgexp": /news\.67\.com\/files/,
	"url_example": "http://news.67.com/files/2009/4/2/187572.shtml",
	"updated_at": "2009-04-02",
	"created_by": "ezibo",
	"created_at": "2008-06-16",
	"data": ['iframe[src*="/other/frmCircleNews.htm"]{ display: none !important }']
},
{"name": "deepin",
	"enabled": "true",
	"url_rgexp": "deepin\.org\/read(-htm|\.php)",
	"url_example": "http://soft.deepin.org/read-htm-tid-157832.html",
	"updated_at": "2009-04-02",
	"created_by": "ezibo",
	"created_at": "2008-06-16",
	"data": ['DIV[class="tips black"]{ display: none !important }']
},
{"name": "sina",
	"enabled": "true",
	"url_rgexp": "^http:\/\/(?!blog|tag|video).*\.sina\.com\.cn\/",//http://f1.sina.com.cn    ^http:\/\/.*.sina.com.cn
	"url_example": "http://sports.sina.com.cn/f1/2009-04-08/11464313157.shtml",
	"updated_at": "2009-04-02",
	"created_by": "ezibo",
	"created_at": "2008-06-16",
	"data": [
	'div[class^="topAD"],div[class^="ad"],div[id^="ad"],table[class="adNone"],div[class="S_WC_SBar"],div[id="nav_01"],div[class="hScape8"],div[class="PartE"],div[class="left"],div[id="mmisina"],div[id="ghc1"],div[class="md_3md_blue"],div[id="czBlk"],span[class="medialogo"],table[class="a1"],table[class="agz"],div[style^="float:left; width:950px;"],div[class^="topads"],div[style="border-bottom:1px solid #ebebeb;"],div[style="width:950px; height:30px; margin:0px auto; overflow:hidden;"],div[id="dingtong"],div[class="box"],DIV[class="toollinks"],td[class^="link_2008_"],div[class="blk_10"] ul[class="list_333"],div[class="blk_22"],div[class="sidebarOlpc"],td[align="right"]div[class="blkTopGoogleSearch"],div[class^="Ad_"],div[class="sidebar"],div[id="realstock"]{ display: none !important }',
	'#conBody>#page>.Main>.sidebar{ display:none ! important }',
	'.lc_blue,.artibody,.lc_blue h1{width:auto !important;}',
	'div[class="blkContainer"]{width:100% !important;}',
	'div[class="blkContainerSblk"]{width:auto !important;}'
	]
},
{"name": "qidian",
	"enabled": "true",
	"url_rgexp": "^http:\/\/.*\.qidian\.com\/BookReader",
	"url_example": "http://www.qidian.com/BookReader/174075,4463076.aspx",
	"updated_at": "2009-04-02",
	"created_by": "ezibo",
	"created_at": "2008-06-16",
	"data": [
	'table[id="showTB"],div[id="hidden_it"],div[id="LeftDiv"],SPAN[style="color:#E7F4FE"]{ display: none !important }',
	'div[width="945"][height="30"]{ display: none !important }',
	'div[style="text-align:center; clear:both"]{ display: none !important }',
	'iframe[src*="http://cj.qidian.com/"]{ display: none !important }',
	'#show_it,#hidden_it,#AddMark { display:none !important;}',
	'.zsdiv1 iframe { display:block !important;}'
	]
},
{"name": "163",
	"enabled": "true",
	"url_rgexp": "^http:\/\/(?!blog).*\.163\.com\/",
	"url_example": "http://sports.163.com/09/0413/07/56OU4HA100051CA1.html",
	"updated_at": "2009-04-02",
	"created_by": "ezibo",
	"created_at": "2009-04-13",
	"data": [
	'div[CLASS="ad360"],[CLASS="AdBox"],[CLASS="adRtext"],[class="adRPicText"]{ display: none !important }',
	'div[id*="ead_ad"],[class="endContent"],[class="endYoDao"],[class="endPage_Nav"],[class="endRightTitle"],[class="endRightContent"],[class="end_r_hr"]{ display: none !important }',
	'div[class="foot"]{ display: none !important }',
	'iframe[src*="http://pro.163.com/"],embed[src*="http://img1.126.net"]{ display: none !important }',
	'.endArea .col1{width: 100% !important}',
	'.bg_endPage_Lblue,.endContent{ display:block !important; background-image:none !important;; background-color:#f7fcff !important; padding:12px 100px 9px !important }',
	'#endMain,.blankWhiteBox,.theCurrent{width:auto !important;}',
	]
},

{"name": "BaiduCss",
	"enabled": "true",
	"url_rgexp": "http://www.baidu.com/b",
	"url_example": "http://tieba.baidu.com/f?kz=307651107",
	"css_src": "file://localhost/D:/Program%20Files/Opera/profile/styles/user/user.css",
	"data": [
	]
},
{"name": "BaiduTieba",
	"enabled": "true",
	"url_rgexp": "http://tieba.baidu.com/f",
	"url_example": "http://tieba.baidu.com/f?kz=307651107",
	"updated_at": "2009-04-15",
	"created_by": "ezibo",
	"created_at": "2009-04-13",
	"data": [
	'table[id="rightAd"]{ display: none !important }',
	'body{overflow-x:hidden !important;}',
	'#vote_item_parent{background-color:transparent !important}',
	'#vote_item_parent *{background-color:transparent !important}',
	'.ntb{background-color:#3A437B  !important;height:29px !important;margin:6px 0px !important}',
	'.ntb *{background:transparent none !important}',
	'#tobar{background-color:#3A437B  !important;height:29px !important;margin:6px 0px !important}',
	'#tobar a{color:#fff !important;}',
	'a{text-decoration:none !important;}',
	'.gray14{border:1px solid #897A41 !important;background:#F5FBFC url(http://hiphotos.baidu.com/yx2046/pic/item/7e8d2331c7c0dd87a8018edd.jpg) repeat 0px top !important;padding:20px 20px !important;line-height:26px !important;}',
	'td.p14 *{color:#000092 !important}',
	'td.au a{color:#000092 !important}',
	'div.auw{color:#000092 !important}',
	'a:link{color:#000092 !important}',
	'a:visited{color:#1F3A87 !important}',
	'a:hover{color:#D40909 !important;text-decoration:underline !important}'
	]
},
{"name": "ifeng",
	"enabled": "true",
	"url_rgexp": "^http:\/\/.*\.ifeng\.com\/",
	"url_example": "http://finance.ifeng.com/money/wealth/staff/20090416/547286.shtml",
	"updated_at": "2009-04-15",
	"created_by": "ezibo",
	"created_at": "2009-04-13",
	"data": [
	'div[id="final_navi_top"],[id="final_head_ad"],[id="main_right"],[class="ad_pic"],[class="ad_text"],[id="back"],[id="footer"].mainhead,.boxFoot{ display: none !important }',
	'div[id^="artical"] {width:950px !important;}'
	]
},
{"name": "xiaonei",
	"enabled": "true",
	"url_rgexp": "^http:\/\/.*\.xiaonei\.com\/",
	"url_example": "http://friend.xiaonei.com/myrelationperson.do",
	"updated_at": "2009-04-15",
	"created_by": "ezibo",
	"created_at": "2009-04-13",
	"data": [
	'#pageStatus #status-list li {overflow:visible !important;}',
	'div[class="banner clearfix"]{ display: none !important }'
	]
},
{"name": "sohu",
	"enabled": "true",
	"url_rgexp": "^http:\/\/(?!blog|weblive|club|bbs).*\.sohu\.com\/",
	"url_example": "http://business.sohu.com/20090423/n263585129.shtml",
	"updated_at": "2009-04-02",
	"created_by": "ezibo",
	"created_at": "2009-04-13",
	"data": [
'TABLE[width="350" ][height="250" ],div[id^="ad_"],div[class^="box"],H2[class^="title"],#ad_TOP,.right .idea,.right .tools,.area.ad360{display:none !important;}',
'#r_col,#foot,#banner_product,div[id^="ad_"],div[id^="TurnAD"],div[class^="ad"],div[class^="bigAd"],[class^="channelLOGO AD"],div.picList.Area{display:none !important;}',
'html>body.bodybg>div#contentB.area{display:none !important;}',
	'#contentB>.left,.article_area{width:100% !important;}',
	'#contentText,.lc,div#sohu_content.article{width:95% !important;}',
	'a {text-decoration: none !important;}'
	]
	},
	{"name": "QQ",
	"enabled": "true",
	"url_rgexp": "^http:\/\/(?!blog).*\.qq\.com\/",
	"url_example": "http://news.qq.com/a/20090403/001139.htm",
	"updated_at": "2009-04-24",
	"created_by": "deform",
	"created_at": "2009-04-24",
	"data": [
'.news_ad_box,#cntR,#AdZoneLc,#PicNews,#AdZoneLe,#PicNewsTit,#AdZoneLa,#hotnews,#qq_NavCenter,#nav,#topAd,.rline,[src^="http://mat1.qq.com/news/images/pub/2007/reading.gif"],.cntMain .cntL .AdZoneLc{display: none !important;}{display:none !important;}',
'.article_area,.location{width:100% !important;}',
'#cntL,#ArticleCnt{width:auto !important;}',
'#cntMain{ display:block !important; background-image:none !important;; background-color:#f7fcff !important}'
	]
	},
	{"name": "linkwan",
	"enabled": "true",
	"url_rgexp": "^http:\/\/www\.linkwan\.com\/", 
	"url_example": "http://www.linkwan.com/gb/broadmeter/VisitorInfo/QureyIP.asp?QureyIP=g.cn&Submit.x=0&Submit.y=0",
	"updated_at": "2009-04-24",
	"created_by": "deform",
	"created_at": "2009-04-24",
	"data": [
	'#ad,#box h1,#box br,#n_copy{ display:none !important;}',
	'#box #line{width:auto !important;float:right !important}',
	'#topbg{height:30px !important;overflow:hidden !important;}',
	'#box a{ display:inline !important;float:none  !important;}'
	]
	},
	{"name": "youku", "enabled": "true", 
"url_rgexp": "^http:\/\/v\.youku\.com\/v_show\/", 
"created_by": "greenworld", 
"created_at": "2009-04-30", 
"data": [ 
'#col3.right,.footerBox,.s_header { display: none !important;}', 
'.videoPlay .player {height:570px !important;width:930px !important;}', 
'.left{width:600px !important;}', 
'.center{float:right !important;margin-right:0px !important;margin-top:570px !important;}' 
] 
}, 
{"name": "youku", "enabled": "true", 
"url_rgexp": "^http:\/\/v\.youku\.com\/v_playlist\/", 
"created_by": "greenworld", 
"created_at": "2009-04-30", 
"data": [ 
'.footerBox{display: none !important;}', 
'.listPlay .player{height:570px !important;width:930px !important;}', 
'.right{margin-top:570px !important;}' 
] 
},
{"name": "sodu", "enabled": "true", 
"url_rgexp": "^http://www.sodu.org\/", 
"created_by": "deform", 
"created_at": "2009-06-10", 
"data": [ 
'html>body>table>tbody>tr>td[align="center"]{display:none !important;}' 
] 
},
{"name": "chinanews", "enabled": "true", 
"url_rgexp": "^http://www.chinanews.com.cn\/", 
"created_by": "deform", 
"created_at": "2009-06-22", 
"data": [ 
'.text_right,#all #banner .banner_3, #container #ngg{ display: none !important }', 
'#all #text .text_left{width:100% !important;}',
'.left_zw{width:95% !important;}',
] 
},
{"name": "clubchina", "enabled": "true",
"url_rgexp": "^http:\/\/(military\.)?club\.china\.com\/",
"created_by": "deform",
"created_at": "2009-06-22",
"data": [
'.forumSider,.headbanner{display:none !important}',
'.signContent{display:none !important}',
'#bodyid #outer #contain-all #forumcontainer .forumBody .forumMain,div.postInfo{width: 100% !important}',
'.postContentBox{width:90% !important;}'
]
}, 
{"name": "china",
	"enabled": "true",
	"url_rgexp": "^http:\/\/(?!blog)(?!bbs)(?!club).*\.china\.com\/",
	"url_example": "http://military.china.com/zh_cn/important/11052771/20090415/15433154.html",
	"updated_at": "2009-04-02",
	"created_by": "ezibo",
	"created_at": "2009-04-13",
	"data": [
	'.huyi,.fullClmAT,.homeheadAT,#chan_mainBlk_rgt,.noPrint,.chan_miscBlk .photo4s,.adclass,#clm01,#EndPageRollText,#ReadingCon,#Reading,[src^="/zh_cn/etc/endpage/img0610/reading.gif"],[src^="/zh_cn/etc/gghead2950.shtml"]{display: none !important }',
	'#chan_mainBlk,#container{ display:block !important; background-image:none !important;; background-color:#ffffff !important; padding:12px 100px 9px !important }',
	'#chan_newsDetail,#chan_mainBlk #chan_mainBlk_lft{width:100% !important;}'
	]
}
);


// ==UserScript==
// @name stylish
// @author ezibo
// @version 1.0
// @description site define css content
// @ujs:category browser: enhancements
// @ujs:published 2009-04-02
// @ujs:modified 2009-04-02
//
// Add URLs to exclude here:
// @exclude file://*
//
// ==/UserScript==

window.DebugMode = true;
if (!window.StylishSiteDefine) {
	window.StylishSiteDefine = [];
}

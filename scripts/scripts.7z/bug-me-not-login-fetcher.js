// ==UserScript==
// @name Bug me not - Login Fetcher
// @author Ayush
// @version 1.2.3
// ==/UserScript==

// How to use -
// Ctrl+Shift+Double-Click  to toggle the visibility of logins.
// Or when userNames/passwords are visible, just double-click anywhere to hide them.
// Or press the close button X

//javascript:alert(document.selectNodes('//FORM[//input[@type="text" or not(@type)] and //input[@type="password"] and (//input[@type="image" or @type="submit"] or //button[@type="submit" or not(@type)])]').length)

(function(){

var showLogins=2; //  max-number of logins to show at one time (scroll down to see other logins)
var UserPassField=1; // find and highlight username-password field on page when you open the BMN frame
var SubmitAfterFilling=1; // submit the form after entering username and password

var inpText,pass,subm,ccr,wtms;
if(/bugmenot\.com.*\?script-ayush$/i.test(location)){
  /* page in bugmenot domain */
  //window.stop();

  /* helper functions */
  window.decoder = function(data) {
    var b64="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",o1,o2,o3,h1,h2,h3,h4,bits,i=0,enc='';
    do {h1=b64.indexOf(data.charAt(i++));h2=b64.indexOf(data.charAt(i++));h3=b64.indexOf(data.charAt(i++));h4=b64.indexOf(data.charAt(i++));bits=h1<<18|h2<<12|h3<<6|h4;o1=bits>>16&0xff;o2=bits>>8&0xff;o3=bits&0xff;if(h3==64)enc+=String.fromCharCode(o1);else if(h4==64)enc+=String.fromCharCode(o1, o2);else enc+=String.fromCharCode(o1,o2,o3);}
    while(i<data.length);
    return enc;
  }
  window.d = function(strInput) {
    strInput=decoder(strInput);
    var strOutput="";var intOffset=(key+112)/12;
    for(i=4;i<strInput.length;i++){thisLetter=strInput.charAt(i);thisCharCode=strInput.charCodeAt(i);newCharCode=thisCharCode-intOffset;strOutput+=String.fromCharCode(newCharCode);}
    document.write(strOutput);
  }
  /* helper functions end */

  /* should be made with httprequest as soon as window.stop() gets fixed */
  /*
  var xml = new XMLHttpRequest();
  xml.onload = function(req) {
    alert(xml.responseText);
  }
  xml.open("GET", location);
  xml.send();
  */

  var rem = 0; window.urchinTracker = function(){};
  // prevent execution of external scripts
  opera.addEventListener("BeforeExternalScript",function(cujse){if(rem)return opera.removeEventListener(cujse.type,arguments.callee,false);cujse.preventDefault(); },false);
  // remove all images
  document.addEventListener("DOMContentLoaded",function(){ var i=document.images,ix=i.length;while(ix)i[--ix].removeNode(); },false);
  document.addEventListener("load",function(){
   stop();
   rem=1;
   if ( !(document.getElementById("document")) ) {
    top.postMessage('bugmenot-error');
    return;
   }
   var cLoginPE=document.getElementById("document").getElementsByTagName("div"); var cont=''
   for(var iX=0;iX<cLoginPE.length;iX++)
     if(/panel minor/i.test(cLoginPE[iX].className)){ cont=cLoginPE[iX]; break }

   var cfms=cont.getElementsByTagName("form");
   while(cfms[0])
     cfms[0].parentElement.removeChild(cfms[0]);

   var tr3=cont.getElementsByTagName("th");
   for(var iX=0;iX<tr3.length;iX++)
     if(tr3[iX].textContent=="Other"){
       var tr3Par=tr3[iX].parentElement;
       tr3Par.parentElement.removeChild(tr3Par)
     }

   var oneLog=document.getElementsByTagName("table"),normdv=(oneLog.length&&oneLog[0])||{offsetWidth:300,offsetHeight:100}
   cont.removeChild(cont.getElementsByTagName("h2")[0])

   document.getElementsByTagName('head')[0].appendChild(document.createElement("style")).text='div{height:'+normdv.offsetHeight+'px !important} table{border:1px dashed black}';

   var closeB=document.createElement("span");closeB.innerHTML="x"
   closeB.style="font-size:20px;color:red;position:fixed;top:0px;right:5px";
   closeB.setAttribute("onclick","top.postMessage('bugmenot-close')")
   cont.appendChild(closeB)

   var dde=document.body;
   dde.style.margin=0;dde.style.overflow='hidden';
   dde.style.width=+normdv.offsetWidth+22+'px';
   dde.innerHTML = cont.innerHTML
   var hgt=(isNaN(showLogins)||oneLog.length<=showLogins)?0:oneLog[showLogins].offsetTop-4

   var wand=document.createElement('div');wand.style="background-image:-o-skin('Wand');width:20px!important;height:20px!important;position:absolute;cursor:hand";
   var ckFunc=function(){ var un_pw=this.parentElement.getElementsByTagName('td');if(un_pw.length>1){parent.postMessage('bugmenot-wand/'+un_pw[0].lastChild.textContent+'/'+un_pw[1].lastChild.textContent)}else alert('bmn-doc:username/pass fields not found!!') };
   for(var iX=0,curr,cw;curr=oneLog[iX++];){
    cw=wand.cloneNode(false);cw.onclick=ckFunc;
    cw.style.top=(curr.offsetTop+curr.offsetHeight-18)+"px";
    cw.style.left=(curr.offsetLeft+1)+"px";
    curr.appendChild(cw);
   }
   var p=document.body.all[0]
   if(p.tagName=="div")p.style="padding:14px;font:12px 400 'trebuchet ms'";
   parent.postMessage((hgt||dde.scrollHeight) + "/" + dde.offsetWidth);
   if(UserPassField)parent.postMessage('bugmenot-wand');
  },false)
}else{
  /* any other NOT bugmenot webpage */
  window.addEventListener("message",function(){
   if(!event.target.document.domain.indexOf("bugmenot.com")|| !crn)return;
   var dde=event.data.split("/");
   switch(dde[0]){
    case "bugmenot-close":	cChangeVis('hidden1',ccr);break;
    case "bugmenot-error": wtms.textContent="Error checking logins!";setTimeout(function(){cChangeVis('hidden1',wtms)}, 3000);break;
    case "bugmenot-wand" :
    	if(!inpText||!pass){
    	 var docForm=document.selectNodes('//FORM[descendant::input[@type="text" or not(@type)] and descendant::input[@type="password"]]')[0];
    	 if(!docForm)return// alert('docForm not found !');
    	 for(var iX=0,E;E=docForm.elements[iX++];)
    	  if(E.currentStyle.visibility=="hidden" || E.currentStyle.display=="none")
    	  	continue
    	  else if(E.type=="text" || !E.type){
    	  	inpText=E;if(pass)break;
    	  }else if(E.type=="password"){
    	  	pass=E;
    	  	if(inpText)break;
    	  }
    	 if(!inpText||!pass)return alert('inpText/pass !');
    	 subm=document.createElement('FORM').submit;
    	 pass.style.border=inpText.style.border="1px groove yellow";
    	};
    	if(dde[1]&&dde[2]){inpText.value=dde[1];pass.value=dde[2];if(SubmitAfterFilling)subm.call(inpText.form) };
    	break;
    default:	ccr.style.height=dde[0]+'px!important';ccr.style.width=dde[1]+'px!important';wtms.style.visibility='hidden';ccr.style.visibility='';

   }
  },false)
}


var crn,fAde;
addEventListener("dblclick",function(){MinFunc(event)},false);

function MinFunc(evt){
 var cev=evt;if(!document.body || cev.altKey)return;else {var cCSH=(cev.ctrlKey && cev.shiftKey)}
 if(crn){
   cChangeVis((ccr.style.visibility!='hidden'?'hidden1':(!cCSH?'-':'')),ccr)
 }else if(cCSH){
   ccr=document.createElement("iframe");
   ccr.style="position:fixed;bottom:0;left:0;width:400px;height:100px;opacity:1;visibility:hidden;border:2px inset black;z-index:1001";
   ccr.src='http://www.bugmenot.com/view/'+location.hostname.replace(/^www\./,'')+'?script-ayush';  // have to remove www. or else bugmenot will redirect us and thus get out of iframe

   wtms=document.createElement("span");
   wtms.style='background-color:black;opacity:0.5;width:220px;height:50px;text-align:center;position:fixed;bottom:0;left:0;visibility:visible;color:white;font:bold 11pt "trebuchet ms";border:2px dotted gray;z-index:1002';
   wtms.textContent="Please wait...";wtms.addEventListener('dblclick',function(){cChangeVis('hidden1',this);},false)

   document.body.appendChild(ccr)
   document.body.appendChild(wtms);
   crn=1
 }
}
window.MinFunc=MinFunc;
function cChangeVis(cSt,elem){
 if(fAde||cSt=='-')return; elem.style.visibility='visible';
 fAde=setInterval(function(){
  elem.style.opacity=+elem.style.opacity+(cSt?-0.15:+0.15);
  var c=elem.style.opacity;
  if(c<=0||c>=1){
   clearInterval(fAde);fAde=0
   elem.style.visibility=cSt.slice(0,-1);elem.style.opacity=cSt.slice(-1)?0:1
  }
 },elem.tagName.toLowerCase()=='span'?32:1)
}
})()
// ==UserScript==
// @include http://u.115.com/file/*
// ==/UserScript==

document.addEventListener('DOMContentLoaded',
function() {
    if (!document.getElementById('busy_remain')) return;
    var url = "http://u.115.com/?ct=upload_api&ac=get_pick_code_info&pickcode=" + file_id + "&version=3";
    var http_request = false;
    if (window.XMLHttpRequest) {
        http_request = new XMLHttpRequest();
        if (http_request.overrideMimeType) {
            http_request.overrideMimeType('text/xml');
        }
    }
   if (!http_request) return;
 	url = "https://webcache.googleusercontent.com/search?client=opera&rls=zh-cn&sourceid=opera&q=cache:http%3A%2F%2Fu.115.com%2Ffile%2Ff85537ab36";
	http_request.open('GET', url, false);
    http_request.setRequestHeader("content-length", url.length);
    http_request.setRequestHeader("content-type", "application/x-www-form-urlencoded");
    http_request.send(null);
	alert(http_request.responseText);
    res = eval("(" + http_request.responseText + ")");
    urltel = res.DownloadUrl[0].Url;
    urlcnc = res.DownloadUrl[1].Url;
    urlbak = res.DownloadUrl[2].Url;
    busy_remain.className = "clearfix";
    busy_remain.innerHTML = "<a class='normal-down' href='" + urltel + "'>电信1下载</a><a class='normal-down' href='" + urlcnc + "'>网通1下载</a><a class='normal-down' href='" + urlbak + "'>备份下载</a>";
}
,false);

function googlecache(){
	var afterIframe = document.body; 
	var myIframe = document.createElement('iframe'); 
	myIframe.src = "https://webcache.googleusercontent.com/search?client=opera&rls=zh-cn&sourceid=opera&q=cache:http%3A%2F%2Fu.115.com%2Ffile%2Ff85537ab36"; 
	myIframe.setAttribute('id',"myIframe");
	myIframe.addEventListener('load',function(){
		//this.ownerDocument
		alert(this.innerHTML);
	},false);
	afterIframe.parentNode.insertBefore(myIframe, afterIframe); 
}

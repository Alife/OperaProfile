// ==UserScript==
// @include http://www.gougou.com/*
// ==/UserScript==
window.opera.defineMagicFunction(
    "check",
    function() {
         var key=s1.value;
         location.href = "http://www.gougou.com/search?search="+ key +"&id=utf-8";
    }
);
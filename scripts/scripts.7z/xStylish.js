﻿// ==UserScript==
// @name stylish
// @author ezibo
// @version 1.0
// @description site define css content
// @ujs:category browser: enhancements
// @ujs:published 2009-04-02
// @ujs:modified 2009-04-02
//
// Add URLs to exclude here:
// @exclude file://*
//
// ==/UserScript==

var ezStylishMode;
var edit_mode=false;
var adr=location.href;
var statusSymbol,statusDesc;
var domentDomain=document.domain;
var symbolNone='\u2609'
var symbolCookie='\u2606'
var symbolJs='\u2605'
var symbolDisable='\u00D7'
var siteElm,urt;

function ezStylishGetCookie(name){
	var a_all_cookies=document.cookie.split(';');
	var a_temp_cookie='';
	var cookie_name='';
	var cookie_value='';
	var b_cookie_found=false;
	for(i=0;i<a_all_cookies.length;i++)
	{
		a_temp_cookie=a_all_cookies[i].split('=');
		cookie_name=a_temp_cookie[0].replace(/^\s+|\s+$/g,'');
		if(cookie_name==name)
		{
			b_cookie_found=true;
			if(a_temp_cookie.length>1){
				cookie_value=unescape(a_temp_cookie[1].replace(/^\s+|\s+$/g,''));
			}
			return cookie_value;
			break;
		}
		a_temp_cookie=null;
		cookie_name='';
	}
	if(!b_cookie_found){
		return null;
	}
}

function ezStylishSetCookie(name,value,expires,path,domain,secure){
	ezStylishDelCookie(name);
	var expDays = expires*24*60*60*1000;
	var expDate = new Date();
	expDate.setTime(expDate.getTime()+expDays);
	var expString = ((expires==null) ? "" : (";expires="+expDate.toGMTString()))
	var pathString = ((path==null) ? "" : (";path="+path))
	var domainString = ((domain==null) ? "" : (";domain="+domain))
	var secureString = ((secure==true) ? ";secure" : "" )
	document.cookie=encodeURIComponent(name)+'='+encodeURIComponent(value)+expString+pathString+domainString+secureString;
}

function ezStylishDelCookie(name){
    var exp = new Date();
    exp.setTime(exp.getTime() - 10000);
    var cval=ezStylishGetCookie(name);
		var pathString=";path=/";
		var domainString=";domain="+domentDomain;
    if(cval!=null)document.cookie=encodeURIComponent(name) + "="+encodeURIComponent(cval)+";expires="+exp.toGMTString()+pathString+domainString;
}

function ezStylishCurDate(){
	var d = new Date();
	var year = d.getFullYear();
	var month = d.getMonth()+1;
	var date = d.getDate();
	var day = d.getDay();
	var cd= year;
	if(month>9)cd = cd +"-"+month;
	else cd = cd +"-0"+month;
	if(date>9) cd = cd +"-"+date;
	else cd = cd +"-0"+date;
	return cd;
}

function for_each(tgt,proc) {
	for(var i=0;i<tgt.length;i++) {
		proc(tgt[i],i)
	}
}
function and_each(tgt,proc) {
	for(var i=0;i<tgt.length;i++) {
		var r=proc(tgt[i])
		if(!r) return false
	}
	return true;
}
function or_each(tgt,proc) {
	for(var i=0;i<tgt.length;i++) {
		var r=proc(tgt[i])
		if(r) return true
	}
	return false;
}
function filter(arr,pred) {
	var result=[];
	for_each(arr,function(i){ if(pred(i)) result.push(i) });
	return result;
}
function index_of(tgt,pred) {
	for(var i=0;i<tgt.length;i++) {
		if(pred(tgt[i])) return i
	}
	return -1
}

function having(target_string,regex_array) {
	var match=or_each(regex_array,function(r){
		return r.test(target_string)
	})
	return match
}
function traverse_elements_with_pruning(elm,f) {
	var r=f(elm)
	if(r) {
		for_each(elm.childNodes,function(c) {
			traverse_elements_with_pruning(c,f)
		})
	}
}

function dict_each(obj,proc) {
	var normal_object={}
	for(var key in obj) {
		if(obj[key]===normal_object[key])
			continue
		proc(key,obj[key])
	}
};
var add_events_temporary=function(target,events) {
	dict_each(events,function(k,v) {
		target.addEventListener(k,v,true)
	})
};
var remove_events=function(target,events) {
	dict_each(events,function(k,v) {
		target.removeEventListener(k,v,true)
	})
};
var add_events=function(target,events) {
	add_events_temporary(target,events)
	var onunload_orig=document.onunload
	document.onunload=function(e) {
		remove_events(target,events)
		if(onunload_orig)
		onunload_orig(e)
	}
};
function create_element(name,style,attrs,child) {
	if(!style) style={}
	if(!attrs) attrs={}
	var e=document.createElement(name)
	dict_each(style,function(k,v){ e.style[k]=v })
	dict_each(attrs,function(k,v){ e[k]=v })
	var append_child=function(child) {
		if(child===null || child===void(0)) return
		else if(new Object(child) instanceof String) e.appendChild(document.createTextNode(child))
		else if(child instanceof Element) e.appendChild(child)
		else throw 'create_element::append_child: unknown child type: '+child
	}
	if(child instanceof Array) { for_each(child,append_child) }
	else append_child(child)
	return e
};

function create_dialog(dlg_def,ctrl_defs) {
	var container=create_element('form',{
		//~ margin:'0',
		padding:'1em',
		backgroundColor:'#eee',
		border:'2px solid #bbb',
		textAlign:'left',
		position:'absolute',
		left:'20px',
		top:document.body.scrollTop,
		zIndex:9999
	});
	if(dlg_def.title) container.appendChild(create_element('h1',{},{},dlg_def.title));
	var controls={};
	var handler=null;
	var create_control=function(def,no_register) {
		if(def instanceof Array) {
			var c=create_element('div')
			for_each(def,function(d){c.appendChild(create_control(d))})
			return c
		} else if(def.multi) {
			function clone(obj) {
				var o={}
				for(var key in obj)
					o[key]=obj[key]
				return o
			}
			var container=create_element('ol');
			controls[def.name]=[];
			for_each(def.value||[],function(val,index) {
				var d=clone(def);
				d.multi=false;
				d.value=val;
				d.name=def.name+'.'+index;
				var c=create_control(d,true);
				controls[def.name].push(c);
				container.appendChild(create_element('li',{},{},c));
			})
			return container
		} else {
			var result=null
			switch(def.type) {
			case 'text':
				result=create_element('input',{},{type: 'text', name: def.name, size: def.size||32, value: def.value});
				break;
			case 'textarea':
				result=create_element('textarea',{},{name: def.name, rows: def.rows, cols: def.cols}, def.value);
				break;
			case 'button':
				if(def.value==null||def.value=='')def.value=def.name;
				result=create_element('input',{},{type: 'button', name: def.name, value: def.value});
				result.onclick=function(){handler(result.name)};
				break;
			default:
				throw 'create_dialog::create_control: unknown def: '+def;
			}
			if(!no_register) controls[def.name]=result;
			return result;
		}
	}
	for_each(ctrl_defs,function(def) {
		var dt=create_element('dt',{},{},def.name);
		container.appendChild(dt);
		var dd=create_element('dd');
		container.appendChild(dd);
		var c=create_control(def);
		dd.appendChild(c);
	})
	var get_form_value=function(elm) {
		var tag=elm.tagName.toLowerCase();
		if(tag=='input') {
			var type=elm.type.toLowerCase();
			if(type=='text') {
				return elm.value;
			} else if(type=='button') {
				return elm.value;
			}
		} else if(tag=='textarea') {
			return elm.value;
		} else throw 'get_form_value: unknown control: '+ta;
	}
	return {
	show: function(user_handler) {
		var self=this;
		handler=function(name) {
			dict_each(controls,function(cname,control) {
				var control=controls[cname];
				if(control instanceof Array) {
					self[cname]=[];
					for_each(control,function(c) {
						self[cname].push(get_form_value(c));
					})
				} else {
					self[cname]=get_form_value(control);
				}
			})
			if(user_handler[name]) {
				if(user_handler[name]()) {
					document.body.removeChild(self.container);
				}
			}
		}
		document.body.appendChild(this.container);
	},
	controls: controls,
	container: container
	}
}

	var selected_original_style=null
	var selected_element=null
	var selected_history=[]
	var select_element=function(elm,opts) {
		if(!opts) opts={}
		if(!opts.style) opts.style='2px dotted red'
		if(selected_element) {
			if(!opts.noHistory) selected_history.push(selected_element)
			selected_element.style.border=selected_original_style
			selected_element=null
		}
		if(!elm) return
		window.status=get_xpath(elm)
		selected_original_style=elm.style.border
		elm.style.border=opts.style
		selected_element=elm
	}
	var History=function() {
		this.elms=[]
		this.data=[] //operation specific data
		this.operations=[]
		this.paths={}
	}
	History.prototype={
		exec: function(operator,elm,path) {
			this.operations.push(operator)
			if(!path) path=get_xpath(elm)
			if(!this.paths[operator.name])
				this.paths[operator.name]=[]
			this.paths[operator.name].push(path)
			this.elms.push(elm)
			if(elm) {
				this.data.push(operator.do_op(elm))
			} else {
				this.data.push(null)
			}
		},
		undo: function() {
			var operator=this.operations.pop()
			this.paths[operator.name].pop()
			var elm=this.elms.pop()
			var data=this.data.pop()
			if(elm) {
				operator.undo_op(elm,data)
			}
		},
		is_empty: function(op) {
			if(op){
				return this.paths[op]==null?true:this.paths[op].length==0
			}
			else{
				return this.elms.length==0
			}
		},
	}
	var remover={
		name: 'remove',
		do_op: function(elm) {
			var disp=elm.style.display
			elm.style.display='none'
			return disp
		},
		undo_op: function(elm,display) {
			elm.style.display=display
		}
	}
	var wider={
		name: 'wide',
		do_op: function(elm) {
			var w=elm.style.width
			elm.style.width='100%'
			return w
		},
		undo_op: function(elm,w) {
			elm.style.width=w
		}
	}
	var clear={
		name: 'clear',
		do_op: function(elm) {
			var bg=elm.style.background
			elm.style.background='none'
			return bg
		},
		undo_op: function(elm,bg) {
			elm.style.background=bg
		}
	}
	var undo_buffer=new History()
	var remove_element=function(elm) {
		undo_buffer.exec(remover,elm)
	}
	var widden_element=function(elm) {
		undo_buffer.exec(wider,elm)
	}
	var clear_element_bg=function(elm) {
		undo_buffer.exec(clear,elm)
	}


	var events={
		mouseover: function(e) {
			selected_history=[]
			select_element(e.target)
		},
		mouseout: function(e) {
		},
		click: function(e) {
			e.preventDefault()
		},
		keypress: function(e) {
			switch(e.keyCode) {
			case 'f'.charCodeAt(0):
				if(selected_element && selected_element.parentNode!=document)
					select_element(selected_element.parentNode)
				e.preventDefault()
				break;
			case 'r'.charCodeAt(0):
				select_element(selected_history.pop(),{noHistory: true})
				e.preventDefault()
				break;
			case 'z'.charCodeAt(0):
				if(undo_buffer.is_empty()) break
				undo_buffer.undo()
				e.preventDefault()
				break
			case 'w'.charCodeAt(0):
				var selected=selected_element
				widden_element(selected)
				break;
			case 'd'.charCodeAt(0):
				var selected=selected_element
				select_element(null)
				remove_element(selected)
				e.preventDefault()
				break
			case 'x'.charCodeAt(0):
				clear_element_bg(selected_element)
				e.preventDefault()
				break;
			case 'e'.charCodeAt(0):
				EzStylishCookieEditor();
				break;
			case 'c'.charCodeAt(0):
				var selected=selected_element
				showInfo(selected)
				break;
			case 27: // Esc
			case 'q'.charCodeAt(0):
				select_element(null);
				remove_events(document,events);
				edit_mode=false;
				e.preventDefault();
				break;
			}
		}
	}

	EzStylishCookieEditor=function(){
		var container;
		container=document.getElementById('EzStylishJsEditor')
		if(container!=null){
			container.style.display="none";
		}
		container=document.getElementById('EzStylishCookieEditor')
		if(container!=null){
			container.style.display="";
		}
		else{
			container=create_element('form',{
			position: 'fixed !important',
			margin:'0 !important',
			padding:'1em !important',
			backgroundColor:'#eee !important',
			border:'2px solid #bbb !important',
			textAlign:'left !important',
			left:'20px !important',
			top:'0 !important',
			//~ top:document.body.scrollTop,
			zIndex:'9999 !important'
			},{id:'EzStylishCookieEditor'});
			container.appendChild(create_element('h3',{},{},"站点css调试编辑器"));
			var cssc="";
			var buffer="";
			var ht;
			if(ezStylishMode=="COOKIE"){
				cssc=CookieCssContent;
				ht="Cookie中保存的内容";
			}
			else{
				cssc=JsCssContent
				ht="Stylish.SITEDEFINE.js保存的内容";
			}

			container.appendChild(create_element('h5',{},{},ht));
			container.appendChild(create_element('textarea',{},{id: 'ezStylishCssc', rows: 5, cols: 80}, cssc));

			if(!undo_buffer.is_empty('remove')){
				buffer=undo_buffer.paths['remove'].join("{display: none !important;}\n")+"{display: none !important;}\n"
			}
			if(!undo_buffer.is_empty('wide')){
				buffer=buffer+undo_buffer.paths['wide'].join("{width:100% !important;}\n")+"{width:100% !important;}\n"
			}
			if(!undo_buffer.is_empty('clear')){
				buffer=buffer+undo_buffer.paths['clear'].join("{background: none !important;}\n")+"{background: none !important;}\n"
			}
			container.appendChild(create_element('h5',{},{},"当前操作的内容"));
			container.appendChild(create_element('textarea',{},{id: 'ezStylishBuffer', rows: 5, cols: 80}, buffer));
			var d=create_element('div',{},{});
			result=create_element('input',{},{type: 'button', name: 'saveCookie', value: '临时保存到Cookie'});
			result.onclick=function(){
				cssc=document.getElementById('ezStylishCssc').value+document.getElementById('ezStylishBuffer').value
				ezStylishSetCookie('ezStylishCSSContent',cssc,365,'/',domentDomain);
				ezStylishSetCookie('ezStylishMode',"COOKIE",365,'/',domentDomain);
				document.body.removeChild(container);
				edit_mode=false;
				return true;
			}
			d.appendChild(result)
			result=create_element('input',{},{type: 'button', name: 'cancel', value: '取消'});
			result.onclick=function(){
				document.body.removeChild(container);
				remove_events(document,events);
				edit_mode=false;
				return true;
			}
			d.appendChild(result)

			result=create_element('input',{},{type: 'button', name: 'saveJavascript', value: '保存到JS文件'});
			result.onclick=function(){
				//~ document.body.removeChild(container);
				ShowEzStylishJsEditor();
				container.style.display="none";
				remove_events(document,events);
				edit_mode=false;
				return true;
			}
			d.appendChild(result)
			container.appendChild(d)
			document.body.appendChild(container);
			remove_events(document,events)
			edit_mode=false;
			return true;
			//~ e.preventDefault()
		}
	}

	function CloseEzStylishJsEditor(){
		var container=document.getElementById('EzStylishJsEditor');
		document.body.removeChild(container);
		remove_events(document,events);
		edit_mode=false;
		return true;
	}

function checkEleValue(ele,tip){
	var data=document.getElementById(ele).value
	if(data==""||data.replace(/ /g,"")==""){alert(tip);ele.focus();return false}
	else return true
}

function ezGetPattern(p){
	if(p){
		var s=p.toString()
		if(urt=='/')return s.substring(1,s.length-1)
		else return p
	}
}

function SaveCSS2JS(){
	if(document.getElementById('ezstylish_tip').innerText!="正确"){alert("请先写对正则");return false;}
	if(!checkEleValue('ezstylish_name','名字还是有用的，请加上一个'))return false
	if(!checkEleValue('ezstylish_url_regexp','必需要有正则表达式'))return false
	if(!checkEleValue('ezstylish_url_example','加个网址例子，方便看效果'))return false
	if(!checkEleValue('ezstylish_data','没有代码？那点保存干嘛？'))return false
	var act
	if(document.getElementById('ezstylish_url_regexp_org').value==''){
		act='stylish_new';
	}
	else{
		act='stylish_mod';
		act+='\n'+urt+document.getElementById('ezstylish_url_regexp_org').value+urt;
	}
	act+='\n{"name":"'+document.getElementById('ezstylish_name').value+'",';
	var tf=(document.getElementById('ezstylish_enabled').checked)?'true':'false';
	act+='\n\t"enabled":"'+tf+'",';
	var v=document.getElementById('ezstylish_url_regexp').value
	if(v.indexOf('://')>=0){v='"'+v+'"'}
	else{v='/'+v+'/'}
	act+='\n\t"url_regexp":'+v+',';
	act+='\n\t"url_example":"'+document.getElementById('ezstylish_url_example').value+'",';
	act+='\n\t"updated_at":"'+document.getElementById('ezstylish_updated_at').value+'",';
	act+='\n\t"created_by":"'+document.getElementById('ezstylish_created_by').value+'",';
	act+='\n\t"created_at":"'+document.getElementById('ezstylish_created_at').value+'",';
	act+='\n\t"data":[\n\''+document.getElementById('ezstylish_data').value.replace(/\r/g,"\\")+'\']\n},';
	opshell(act);
}

function JsDisableCurrentSite(){
	if(siteElm==null){
		alert('Stylish的站点定义中还没有规则适合当前站点，所以无需禁用');
	}
	else{
		var c=window.confirm("这将清除修改Stylish.SITEDEFINE.js中站点设置enable属性。\n是否继续？");
		if(c){
			var act='stylish_dcs';
			act+='\n'+siteElm.url_regexp;
			opshell(act);
		}
	}
}

function EditSiteInNotepad(){
	var act='stylish_esin';
	if(siteElm!=null){act+='\n'+siteElm.url_regexp;}
	opshell(act);
}

opshell=function(act){
	var fr=document.createElement('iframe');
	fr.setAttribute('id', 'tr_dummy');
	fr.setAttribute('frameborder', '0');
	fr.setAttribute('style', 'width:0px;height:0px;visibility:hidden;position:absolute;left:-999em;');
	fr.setAttribute('src', 'data:text/opshell;charset=UTF-8,'+encodeURIComponent(act));
	document.documentElement.appendChild(fr);
	var tr=document.getElementById('tr_dummy');
	tr.parentNode.removeChild(tr);
}

function DelEzStylishCookie(){
	if(ezStylishMode==null){
		alert('Cookie中无内容，所以无作用');
	}
	else{
		var c=window.confirm("这将清除Stylish存放在Cookie中的记录，回到一般浏览模式，对Stylish.SITEDEFINE.js中的定义不影响。\n是否关闭？");
		if(c){
			ezStylishDelCookie("ezStylishMode");
			ezStylishDelCookie("ezStylishCSSContent");
			if(window.confirm("现在已回到一般浏览模式\n是否刷新以查看效果？"))location.reload();
		}
	}
}

function CookieDisableCurrentSite(){
	var c=window.confirm("这将在当前网站临时禁用或者恢复Stylish。\n是否继续？");
	if(c){
		if(ezStylishMode=="PAUSE"){
			if(CookieCssContent){
				ezStylishDelCookie('ezStylishMode');
				ezStylishSetCookie('ezStylishMode',"COOKIE",365,'/',domentDomain);
			}
			else{
				ezStylishDelCookie('ezStylishMode');
			}
		if(window.confirm("启用后要刷新才能看到效果\n是否刷新？"))location.reload();
		}
		else{
			ezStylishSetCookie('ezStylishMode',"PAUSE",365,'/',domentDomain);
			if(window.confirm("临时停用后要刷新才能看到效果\n是否刷新？"))location.reload();
		}
	}
}

ShowEzStylishJsEditor=function(){
	var container;
	container=document.getElementById('EzStylishCookieEditor')
	if(container!=null){
		container.style.display="none";
	}
	container=document.getElementById('EzStylishJsEditor')
	if(container!=null){
		container.style.display="";
	}
	else{
		container=create_element('form',{
			position: 'fixed !important',
			margin:'0 !important',
			padding:'1em !important',
			backgroundColor:'#eee !important',
			border:'2px solid #bbb !important',
			textAlign:'left !important',
			left:'20px !important',
			top:'0 !important',
			zIndex:'9999 !important'
		},{id:'EzStylishJsEditor'});
		container.appendChild(create_element('h3',{},{},"Stylish.SITEDEFINE.js站点编辑器"));
		document.body.appendChild(container);
container.innerHTML="<table width='45%' border='1' cellpadding='1' cellspacing='0' class='ezstyle'>\
  <tr>\
    <td width='15%'>站点名称:</td>\
    <td width='19%'>\
      <input type='text' name='ezstylish_name' id='ezstylish_name' size='15' title='简短的网站名称，比如sina,建议不用中文，默认为域名'>\
      <input type='hidden' name='ezstylish_name_org' id='ezstylish_name_org'>\
      <input type='hidden' name='ezstylish_url_regexp_org' id='ezstylish_url_regexp_org'>\
      <input type='hidden' name='ezstylish_created_at' id='ezstylish_created_at'></td>\
    <td width='20%'>启用Stylish:</td>\
    <td width='46%'>\
      <input type='checkbox' name='ezstylish_enabled' id='ezstylish_enabled' value='true' title='当前网站是否启用Stylish'></td>\
  </tr>\
  <tr>\
    <td width='15%'>网址正则:</td>\
    <td colspan='3'>\
      <input type='text' name='ezstylish_url_regexp' id='ezstylish_url_regexp' size='50' onchange='ezStylishCheckReg(this.value)' title='高手们都写成例如 ^http:\/\/(?!blog|tag).*\.sina\.com\.cn\/ 这样呢'>\
      <font id='ezstylish_tip' color='#FF0000'>提示</font>\
    	<span id='ezstylish_regtip' title='点击查看正则表达式的语法帮助' style='cursor:help' onclick='EzStylishHelpReg()'>语法帮助</span></td>\
  </tr>\
  <tr>\
    <td width='15%'>网址例子:</td>\
    <td colspan='3'>\
      <input type='text' name='ezstylish_url_example' id='ezstylish_url_example' size='50' title='网址说明，方便将来查看效果'>    </td>\
  </tr>\
  <tr>\
    <td width='15%'>你的名字:</td>\
    <td width='19%'>\
      <input name='ezstylish_created_by' id='ezstylish_created_by' type='text' size='15' title='可不填，你的网名，比如EZ'></td>\
    <td width='20%'>更新日期:</td>\
    <td width='46%'>\
      <input name='ezstylish_updated_at' id='ezstylish_updated_at' type='text' size='15' title='默认为今天'>    </td>\
  </tr>\
  <tr>\
    <td width='15%'>CSS内容:</td>\
    <td colspan='3'>\
<table width='100%' border='0'><tr><td rowspan='2'>\
<textarea name='ezstylish_data' id='ezstylish_data' cols='60' rows='5' title='高手们都写成 #ad,.footer,div[class^=Ad_]这样呢'></textarea></td>\
<td height='45'><font title='点击将打开记事本进行编辑' style='cursor:help' onclick='EditSiteInNotepad()'>直接编辑</font></td></tr>\
<tr><td><font id='csstip' title='点击查看CSS的语法帮助' style='cursor:help' onclick='EzStylishHelpCss()'>语法帮助</font></td></tr></table>\
      </td>\
  </tr>\
<tr>\
    <td><input name='Back2Cookie' type='button' value='回Cookie' onclick='EzStylishCookieEditor()'/></td>\
		<td colspan='2'><input name='SaveStylishJS' type='button' value='保存JS文件' onclick='SaveCSS2JS()' />\
		<input name='cancel' type='button' id='cancel' value='取消' onclick='CloseEzStylishJsEditor()'/></td>\
		<td><span title='高手？那就分享给小白菜鸟们吧' style='cursor:help' onclick='EzStylishPut()'>:)分享！</span>&nbsp;&nbsp;&nbsp;\
		<span title='白菜？那就看看高人们的代码' style='cursor:help' onclick='EzStylishGet()'>:(求助？</span>\
		</td>\
  </tr>\
</table>"

		if(siteElm==null){
			document.getElementById('ezstylish_name').value=location.host
			document.getElementById('ezstylish_enabled').checked=true
			document.getElementById('ezstylish_url_regexp').value=location.href
			document.getElementById('ezstylish_url_example').value=location.href
			document.getElementById('ezstylish_tip').innerText="正确";
			document.getElementById('ezstylish_name_org').value=''
			document.getElementById('ezstylish_url_regexp_org').value=''
			document.getElementById('ezstylish_created_at').value=ezStylishCurDate()
			document.getElementById('ezstylish_created_by').value=EzStylishAuthor
		}
		else{
			document.getElementById('ezstylish_tip').innerText="正确";
			document.getElementById('ezstylish_name').value=(siteElm.name==null)?location.host:siteElm.name
			document.getElementById('ezstylish_enabled').checked=(siteElm.enabled==null||siteElm.enabled=="true")?true:false
			document.getElementById('ezstylish_url_regexp').value=(siteElm.url_regexp==null)?location.href:ezGetPattern(siteElm.url_regexp)
			document.getElementById('ezstylish_url_example').value=(siteElm.url_example==null)?location.href:siteElm.url_example
			document.getElementById('ezstylish_name_org').value=siteElm.name
			document.getElementById('ezstylish_url_regexp_org').value=(siteElm.url_regexp==null)?location.href:ezGetPattern(siteElm.url_regexp)
			document.getElementById('ezstylish_created_at').value=siteElm.created_at
			document.getElementById('ezstylish_created_by').value=siteElm.created_by
		}
		document.getElementById('ezstylish_updated_at').value=ezStylishCurDate()
		var tr_data;
		if(document.getElementById('ezStylishCssc')!=null||document.getElementById('ezStylishBuffer')!=null){
			tr_data=document.getElementById('ezStylishCssc').value+document.getElementById('ezStylishBuffer').value
		}
		else{
			tr_data=JsCssContent;
		}
		document.getElementById('ezstylish_data').value=tr_data.replace(/\t/g,"\n")
		remove_events(document,events)
		edit_mode=false;
		return true;
		//~ e.preventDefault()
		}
	}

		var ele='',outline='',border='',bgColor='',title='',reObjects=/^(iframe|object|embed)$/i;
		var doc=((window.document.bodyinstanceofHTMLFrameSetElement)?window.frames[0]:window).document;
		var getAtt=function (ele,tags){
			var rez='';
			if(ele.attributes){
				var r=new RegExp('^('+tags+')$');
				for(var i=0,a;a=ele.attributes[i];i++){
					var n=a.nodeName.toLowerCase();
					if(r.test(n))rez+='['+n+'=\x22'+a.nodeValue+'\x22]'
				}
			};
			return rez
		};

	var getNth=function (elm){
		var nth,n=0;
		var p=elm.parentNode;
		for(var i=0,c;c=p.childNodes[i];i++){
			if(c.nodeType==1){
				n++;
				if(c==elm)nth=n
			}
		};
		return (!nth||n<2)?'':':nth-child('+nth+')'
	};

	var get_xpath=function (elm){
		var att,tag,rez=[];
		while(elm){
			if(elm.nodeType==1){
				att=getAtt(elm,'src')||getAtt(elm,'href')||getAtt(elm,'id');
				tag=elm.nodeName;
				if(att){
					//~ rez.unshift((doc.documentElement.nodeName+getAtt(doc.documentElement,'class')+' ')+tag+att);
					rez.unshift((getAtt(doc.documentElement,'class')+' ')+tag+att);
					break;
				}else {
					rez.unshift(tag+getAtt(elm,'class|height|width|color|bgcolor|align')+((/^(html|body)$/i.test(tag)||!window.postMessage)?'':getNth(elm)))
				}
			};
			elm=elm.parentNode
		};
		return rez.join('>')
	}

	var showInfo=function (elm){
		var t;
		t="页面元素信息\n\nid : "+getAtt(elm,'id')+"\n\n";
		t=t+"class : "+getAtt(elm,'class')+"\n\n";
		t=t+"代码 : \n"+elm.outerHTML;
		alert(t);
	}

	function ezStylishCheckReg(t){
		var o=document.getElementById('ezstylish_tip');
		try{
			if(adr.match(t)){
				if(t.indexOf('\\')>=0){
					if(!/[^\\](\/)/.test(t)){
						o.innerText='正确';
						o.color='blue';
					}
					else{
						o.innerText='写错了';
						o.color='red';
					}
				}
				else{
					o.innerText='正确';
					o.color='blue';
				}
			}
			else{
				o.innerText='写错了';
				o.color='red';
			}
		}
		catch(e){
			//~ opera.postError(e);
			o.innerText='写错了';
			o.color='red';
		}
	}

	EzStylishStart=function(){
		if(!edit_mode) {
			add_events(document,events)
			edit_mode=true
		}
		ShowDivMenu(0);
	}

	var ShowEzStylishObj=function(){
		var a=document.getElementById("ezStylishSymbol");
		a.style.display=(a.style.display=="none")?"":"none";
	}

	function ezStylishMonitorCtrlClick(e){
		if(e && e.button == 0 && !e.shiftKey && !e.altKey){
			var ele = e.target;
			if(e.ctrlKey){
				ShowEzStylishObj();
				e.stopPropagation();
				e.preventDefault();
			}
		}
	}

	var ShowDivMenu=function(d){
		if(d==1){
			divmenu.style.display="";
		}
		else if(d==0){
			divmenu.style.display="none";
		}
	}

	function EzStylishGet(){
		window.open("http://www.operaez.com/stylish/get.asp?url="+adr);
	}

	function EzStylishPut(){
		var f=document.getElementById('EzStylishJsEditor');
		f.action="http://www.operaez.com/stylish/put.asp";
		f.method="post"
		f.target="_blank"
		f.submit();
	}

	function EzStylishHelpCss(){
		window.open("http://www.operaez.com/stuff/css.html");
	}

	function EzStylishHelpReg(){
		window.open("http://www.operaez.com/stuff/regexp.html");
	}

	function attachcss(css){
		try{
			var node = document.body || document.getElementsByTagName('head')[0];
			if (node) {
				var style = document.createElement('style');
				style.textContent = css;
				node.appendChild(style);
			}
		}
		catch(e) {
			opera.postError(e);
		}
	}

(function(){
	SiteDefine = window.StylishSiteDefine || [];
	delete window.StylishSiteDefine;
	var data;
	CookieCssContent=""
	JsCssContent="";
	var OwnCSS=".ezstyle{font-size: 10px;white-space:nowrap;}table#EzStylish-Table { background: #DEE7F7 !important; border: 1px solid #313163 !important; border-collapse: collapse !important; }div.EzStylishSep-Div { font: normal normal 11px/136% Tahoma !important; background: #ACD2F5 !important; border: 1px outset #ACD2F5 !important; color: #3373A6 !important; display: block !important; margin: 1px 0 1px 0 !important; text-align: center !important; }div.EzStylishCnt-Div { display: block !important; }button.EzStylishBut, input.EzStylishBut { font: normal normal 11px/136% Tahoma !important; background: #65A5D8 !important; border-color: #65A5D8 !important; border-width: 1px !important; color: #FFFFFF !important; display: inline !important; float: none !important; font-size-adjust: none !important; letter-spacing: 1px !important; text-decoration: none !important; text-indent: 0 !important; visibility: inherit !important; }button.EzStylishBut { margin: 6px 0 0 0 !important; padding: 0 3px 0 3px !important; text-align: center !important; max-width: 120px !important; height: auto!important; width: auto!important; }a.EzStylishLink, span.EzStylishLink, label.EzStylishLink { font: normal normal 11px/136% Tahoma !important; position: relative !important; left: 0!important; top: 0!important; width: auto !important; height: auto !important; z-index: auto !important; min-width: 0 !important; max-width: none !important; background: transparent !important; border-style: none !important; border-spacing: 2px!important; outline-style: none !important; direction: ltr !important; float: none !important; font-size-adjust: none !important; letter-spacing: 1px !important; margin: 0 !important; padding: 0 !important; text-align: left !important; text-decoration: none !important; text-indent: 0 !important; text-transform: none !important; visibility: inherit !important; white-space: nowrap !important; cursor: hand!important; }div.EzStylishtext { font: normal normal 11px/136% Tahoma !important; }"

	function domain(){
		attachcss(OwnCSS);
		var bHaveJsCss;
		bHaveJsCss=LoadJsCssContent();
		ezStylishMode=ezStylishGetCookie('ezStylishMode')
		try{
			if(ezStylishMode=="COOKIE"){
				statusSymbol=symbolCookie;
				statusDesc="Cookie模式";
				LoadFromCookie();
				attachcss(CookieCssContent);
			}
			else{
				if(bHaveJsCss){
					if(ezStylishMode=="PAUSE"){
						statusSymbol=symbolDisable
						statusDesc="临时暂停C";
						LoadFromCookie();
					}
					else if(siteElm.enabled.toLowerCase()=="true"){
						statusSymbol=symbolJs;
						statusDesc="JS模式";
						attachcss(JsCssContent);
					}
					else if(siteElm.enabled.toLowerCase()!="true"){
						statusDesc="站点停用J";
						statusSymbol=symbolDisable
					}
					else{
						statusDesc="JS模式";
						statusSymbol=symbolJs
					}
				}
				else{
					statusDesc="未启作用";
					statusSymbol=symbolNone
				}
			}
		}
		catch(e){
			opera.postError(e)
		}
	}

	var LoadFromCookie=function() {
		CookieCssContent=ezStylishGetCookie('ezStylishCSSContent');
	}

	var LoadJsCssContent=function(){
		for(var i=0;i<SiteDefine.length-1;i++){
			if(adr.match(SiteDefine[i].url_regexp))
			{
				siteElm=SiteDefine[i];
				urt=(siteElm.url_regexp.length==undefined)?'/':'"';
				data=SiteDefine[i].data;
				for(var n in data) JsCssContent+=data[n]+'\n';
				break;
			}
		}
		if(JsCssContent.length==0){
			return false;
		}
		else{
			return true;
		}
	}
domain()
})();


document.addEventListener('DOMContentLoaded',function() {
var EzStylishAuthor=window.EzStylishAuthor;
var EzStylishShowDivMenu=window.EzStylishShowDivMenu;
delete window.EzStylishShowDivMenu;
var EzStylishCtrlClick=window.EzStylishCtrlClick;
delete window.EzStylishCtrlClick;
	if(window.parent!=window) return;
	var divobj=create_element('div',
	{
		position: 'fixed !important',
		cursor: 'crosshair !important',
		textDecoration: 'none !important',
		padding: '2px !important',
		right: '2px !important',
		top: '2px !important',
		//~ bottom: '2px !important',
		fontSize: '10px',
		textAlign: 'right !important',
		zIndex: '9999 !important',
		fontWeight: 'bold !important',
		display: 'none !important'
		//opacity: '.65'
	},
	{
		onmouseover: function(e){
			divmenu.style.display="";
		},
		//~ onmouseout: function() {
			//~ if(1<this.childNodes.length)
				//~ this.removeChild(this.childNodes[1])
		//~ },
	href: 'javascript:void 0',
	id:"ezStylishSymbol",
	},statusSymbol
	)

	document.body.appendChild(divobj)
	divmenu=divobj.appendChild(create_element('div',{textAlign: 'left',display: 'none'},{onmouseout: function() {ShowDivMenu(0)}}));
var se=(siteElm!=null&&siteElm.enabled=="false")?"checked":""
var cp=(ezStylishMode=="PAUSE")?"checked":""
divmenu.innerHTML="<TABLE id='EzStylish-Table'><TBODY><TR><TD class='EzStylish-L-Td'><DIV class='EzStylishSep-Div'>Stylish</DIV><DIV class='EzStylishCnt-Div'><input name='EzStylishStart' type='button' class='EzStylishBut' onclick='EzStylishStart()' value='开始Stylish' /><br/><input name='EzStylishCookieEditor' type='button' class='EzStylishBut' onclick='EzStylishCookieEditor()' value='Cookie编辑器' /><br/><input name='ShowEzStylishJsEditor' type='button' class='EzStylishBut' onclick='ShowEzStylishJsEditor()' value='站点JS编辑器' /><br/><input name='ShowEzStylishJsEditor' type='button' class='EzStylishBut' onclick='DelEzStylishCookie()' value='关闭Stylish' /></DIV><DIV class='EzStylishSep-Div'>页面状态</DIV><DIV class='EzStylishCnt-Div'><LABEL class='EzStylishLink' title='Cookie中，无论Stylish.SITEDEFINE.js和Cookie中是否有定义都不会起作用，相当于Stylish不存在'><INPUT name='sd' class='EzStylishLink' onclick='CookieDisableCurrentSite()' type='checkbox' value='0' "+ cp +">临时禁用C</LABEL></DIV><DIV class='EzStylishCnt-Div'><LABEL class='EzStylishLink' title='Stylish.SITEDEFINE.js中，enable属性，true启用false不启用'><INPUT name='sd' class='EzStylishLink' onclick='JsDisableCurrentSite()' type='checkbox' " + se +" value='1'>站点停用J</LABEL></DIV><DIV class='EzStylishCnt-Div'><LABEL class='EzStylishLink'>当前:"+statusDesc+"</LABEL></DIV></TD><TD id='EzStylish-R-Td'><DIV class='EzStylishSep-Div'>快捷键说明</DIV><DIV class='EzStylishCnt-Div'><div class='EzStylishtext'>e 打开编辑器<br />d 删除元素<br />w 放大宽度<br />x 清除背景<br />f 选择父节点<br />r 上次的选择<br />z 恢复上一操作<br />c 显示代码<br /></div></DIV><DIV class='EzStylishSep-Div'>帮助</DIV><DIV class='EzStylishCnt-Div'><SPAN class='EzStylishLink' onclick='EzStylishHelpReg()'>正则表达式语法^</SPAN></DIV><DIV class='EzStylishCnt-Div'><SPAN class='EzStylishLink' onclick='EzStylishHelpCss()'>CSS选择器语法^</SPAN></DIV><DIV class='EzStylishCnt-Div'><SPAN class='EzStylishLink' onclick='EzStylishGet()'>当前网址适配的规则?^</SPAN></DIV></TD></TR></TBODY></TABLE>"

			if(EzStylishShowDivMenu) {
				divobj.style.display="";
			}
},false);
if(EzStylishCtrlClick){document.addEventListener('click', ezStylishMonitorCtrlClick, false);}

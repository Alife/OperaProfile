// ==UserScript==
// @name localStorage emulation
// @author Lex1
// @version 1.0
// @include http://*
// @description localStorage emulation for Opera 8.5-10.1. Need MIME-type "text/lse".
// @ujs:download http://ruzanow.ru/userjs/aa_localStorage.js
// ==/UserScript==

(function(){
//storage begin
var storage = {};
//storage end

if(!window.localStorage){
 var encodeBase64 = function(string){var out='',charCode=0,i=0,endBytes='',length=string.length;var puffer=[];var base64EncodeChars="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";while(charCode=string.charCodeAt(i++)){if(charCode<0x80){puffer[puffer.length]=charCode}else if(charCode<0x800){puffer[puffer.length]=0xc0|(charCode>>6);puffer[puffer.length]=0x80|(charCode&0x3f)}else if(charCode<0x10000){puffer[puffer.length]=0xe0|(charCode>>12);puffer[puffer.length]=0x80|((charCode>>6)&0x3f);puffer[puffer.length]=0x80|(charCode&0x3f)}else{puffer[puffer.length]=0xf0|(charCode>>18);puffer[puffer.length]=0x80|((charCode>>12)&0x3f);puffer[puffer.length]=0x80|((charCode>>6)&0x3f);puffer[puffer.length]=0x80|(charCode&0x3f)}if(i==length){while(puffer.length%3){puffer[puffer.length]=0;endBytes+='='}}if(puffer.length>2){out+=base64EncodeChars.charAt(puffer[0]>>2);out+=base64EncodeChars.charAt(((puffer.shift()&3)<<4)|(puffer[0]>>4));out+=base64EncodeChars.charAt(((puffer.shift()&0xf)<<2)|(puffer[0]>>6));out+=base64EncodeChars.charAt(puffer.shift()&0x3f)}}return(out+endBytes)};
 var jsonStringify = (function(){var g=/[\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff\"\\]/g;var h={'\b':'\\b','\t':'\\t','\n':'\\n','\f':'\\f','\r':'\\r','"':'\\"','\\':'\\\\'};var j=function(b){return'"'+b.replace(g,function(a){if(!h[a])h[a]='\\u'+('0000'+a.charCodeAt(0).toString(16)).slice(-4);return h[a]})+'"'};var l=function(d){function f(v){return v<10?'0'+v:v}return'"'+d.getUTCFullYear()+'-'+f(d.getUTCMonth()+1)+'-'+f(d.getUTCDate())+'T'+f(d.getUTCHours())+':'+f(d.getUTCMinutes())+':'+f(d.getUTCSeconds())+'Z"'};var m=function(a,b,e){return a.length===0?b+e:b+'\n'+a.join(',\n').replace(/^/gm,'\t')+'\n'+e};var n=function(a,b){var i,k,v,p=[],o=b[a],t=typeof o,c=Object.prototype.toString.call(o);if(c==='[object Date]')return l(o);if(t==='string'||c==='[object String]')return j(o);if(t==='boolean'||c==='[object Boolean]')return String(o);if(t==='number'||c==='[object Number]')return isFinite(o)?String(o):'null';if(t==='object'){if(!o)return'null';if(Object.prototype.toString.apply(o)==='[object Array]'){for(i=0;i<o.length;i++){p[i]=n(i,o)||'null'};return m(p,'[',']')};for(k in o){if(Object.hasOwnProperty.call(o,k)){v=n(k,o);if(v){p.push(j(k)+': '+v)}}};return m(p,'{','}')}};return function(a){return n('',{'':a})}})();
 var saveFile = function(txt){if(txt.length>131072){alert('Error! String too long!');return};var src='data:text/lse;charset=UTF-8;base64,'+encodeBase64(txt);if(top==self){var f=document.createElement('iframe');f.width=0;f.height=0;f.frameBorder='no';f.scrolling='no';f.src=src;document.documentElement.appendChild(f);setTimeout(function(){f.parentNode.removeChild(f)},1)}else{location.href=src}};

 window.localStorage = storage[location.hostname] || {};
 window.localStorage.getItem = function(name){return this[name]};
 window.localStorage.setItem = function(name, value){this[name] = value; saveFile(jsonStringify({domain: location.hostname, name: name, value: value}))};
 window.localStorage.removeItem = function(name){delete this[name]; saveFile(jsonStringify({domain: location.hostname, name: name, value: undefined}))};
};
})();

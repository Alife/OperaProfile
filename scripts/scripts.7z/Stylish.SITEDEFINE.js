﻿//你的用户名，显示在js编辑器中
window.EzStylishAuthor="ezibo";
//默认是否显示stylish的图标
window.EzStylishShowDivMenu=false;
//是否用Ctrl+点击来显示和关闭stylish图标
window.EzStylishCtrlClick=true;
window.StylishSiteDefine = [
{"name":"feiku",
	"enabled":"true",
	"url_regexp":/^http:\/\/(.*\.)?feiku\.com\/html/,
	"url_example":"http://www2.feiku.com/html//book/130/152703/4126004.shtm",
	"updated_at":"2009-04-04",
	"created_by":"ezibo",
	"created_at":"2009-04-04",
	"data": [
	'fieldset{display: none !important;}',
	'div[id="End"]{display: none !important;}',
	'A[href*="http://www.51.la/"]{display: none !important;}',
	'HTML > BODY > CENTER:nth-child(5) > DIV[id="Ws"] > DIV[id="Top"] > DIV[id="Content"]:nth-child(5) > DIV:nth-child(4){ display: none !important }'
	]
},
{"name":"67",
	"enabled":"true",
	"url_regexp":/news\.67\.com\/files/,
	"url_example":"http://news.67.com/files/2009/4/2/187572.shtml",
	"updated_at":"2009-04-02",
	"created_by":"ezibo",
	"created_at":"2008-06-16",
	"data": ['iframe[src*="/other/frmCircleNews.htm"]{ display: none !important }']
},
{"name":"tianya",
	"enabled":"true",
	"url_regexp":/^http:\/\/.*\.tianya\.cn\//,
	"updated_at":"2009-10-01",
	"created_by":"ezibo",
	"created_at":"2009-10-01",
	"data": [
	'div[id^="adsp_content_adtopic"],div[id^="adsp_content_banner"],div[id^="adsp_content_top_banner"]{ display:none ! important }'
	]
},
{"name":"sina",
	"enabled":"true",
	"url_regexp":/^http:\/\/(?!blog|tag).*\.sina\.com\.cn/,
	"url_example":"http://sports.sina.com.cn/f1/2009-04-08/11464313157.shtml",
	"updated_at":"2009-04-02",
	"created_by":"ezibo",
	"created_at":"2008-06-16",
	"data": [
	'.adNone,.agz,.toollinks,.top_bar,.PartE,.S_WC_SBar,.blk_22,.hScape8,.left,.md_3md_blue,.sidebar,.sidebarOlpc,.medialogo,.footer,.blkTopGoogleSearch,#dingtong,#ghc1,#mmisina,#nav_01,#czBlk,#realstock{ display: none !important }\
	div[class^="Ad_"],div[class^="ad"],div[class^="topAD"],div[class^="topads"],div[id^="ad"],div[class="blk_10"] ul[class="list_333"],div[style="border-bottom:1px solid #ebebeb;"],div[style="width:950px; height:30px; margin:0px auto; overflow:hidden;"],div[style^="float:left; width:950px;"],td[class^="link_2008_"]{ display: none !important }\
	#conBody>#page>.Main>.sidebar{ display:none ! important }\
.blkContentBtmSearch,.blkContentFooter,.sidebar,.topNav,.SearchBar,#GoogleAd{ display: none !important }\
a[href^="http://sina.allyes.com/main/adfclick"]{ display: none !important }\
.lc_blue,.artibody,.lc_blue h1{width:auto !important;}\
div[class="blkContainer"]{width:100% !important;}\
div[class="blkContainerSblk"]{width:auto !important;}'
	]
},
{"name":"sinablog",
	"enabled":"true",
	"url_regexp":/^http:\/\/(blog).*\.sina\.com\.cn\//,
	"url_example":"",
	"updated_at":"2009-04-02",
	"created_by":"ezibo",
	"created_at":"2008-06-16",
	"data": [
	'#xp{ display: none !important }'
	]
},
{"name":"qidian",
	"enabled":"true",
	"url_regexp":/^http:\/\/.*\.qidian\.com\/BookReader/,
	"url_example":"http://www.qidian.com/BookReader/174075,4463076.aspx",
	"updated_at":"2009-04-02",
	"created_by":"ezibo",
	"created_at":"2008-06-16",
	"data": [
	'table[id="showTB"],div[id="hidden_it"],div[id="LeftDiv"],SPAN[style="color:#E7F4FE"],div#AddMark1{ display: none !important }\
	div[width="945"][height="30"]{ display: none !important }\
div[style="text-align:center; clear:both"]{ display: none !important }\
iframe[src*="http://cj.qidian.com/"]{ display: none !important }\
#show_it,#hidden_it,#AddMark { display:none !important;}\
.zsdiv1 iframe { display:block !important;}'
	]
},
{"name":"163",
	"enabled":"true",
	"url_regexp":/^http:\/\/(?!blog|quotes).*\.163\.com\/.*\.html/,
	"url_example":"http://sports.163.com/09/0413/07/56OU4HA100051CA1.html",
	"updated_at":"2010-02-23",
	"created_by":"ezibo",
	"created_at":"2009-04-13",
	"data": [
'.ad360,.AdBox,.adRtext,.adRPicText,.return{ display: none !important }\
.endContent,.endYoDao,.endPage_Nav,.endRightTitle,.endRightContent,.end_r_hr,.foot,.colR{ display: none !important }\
iframe[src*="http://pro.163.com/"],iframe[src^="http://g.163.com/"],embed[src*="http://img1.126.net"]{ display: none !important }\
.endArea, .col1,.endContent,#endText{width: auto !important}\
div[id*="ead_ad"]{ display: none !important }\
.bg_endPage_Lblue,.endContent{ display:block !important; background-image:none !important; background-color:#f7fcff !important; padding:12px 100px 9px !important }\
#endMain,.blankWhiteBox,.theCurrent,.colL{width:auto !important;}']
},
{"name":"sohu",
	"enabled":"true",
	"url_regexp":/^http:\/\/(?!blog|club|bbs).*\.sohu\.com\//,
	"url_example":"http://business.sohu.com/20090423/n263585129.shtml",
	"updated_at":"2009-04-21",
	"created_by":"deform",
	"created_at":"2009-04-21",
	"data": [
'#ad_TOP,.right .idea, .tools,.area.ad360,#r_col,#logo_nav,#foot,#banner_product{display:none !important;}\
div[id^="ad_"],div[id^="TurnAD"],div[class^="ad"],div[class^="bigAd"],[class^="channelLOGO AD"],iframe[src^="http://images.sohu.com"]{display:none !important;}\
TABLE[width="350" ][height="250" ],H2[class^="title"],div[class="right"]>div[class^="box"]{display:none !important;}',
	]
},
{"name":"clubchina",
	"enabled":"true",
	"url_regexp":/^http:\/\/(military\.)?club\.china\.com\/data\/thread\//,
	"created_by":"deform",
	"created_at":"2009-06-22",
	"data": [
'.forumSider,.headbanner{display:none !important}\
.signContent{display:none !important}\
#bodyid #outer #contain-all #forumcontainer .forumBody .forumMain,div.postInfo{width: 100% !important}\
.postContentBox{width:90% !important;}'
	]
},
{"name":"BaiduTieba",
	"enabled":"true",
	"url_regexp":/http:\/\/tieba.baidu.com\/f/,
	"url_example":"http://tieba.baidu.com/f?kz=307651107",
	"updated_at":"2009-04-15",
	"created_by":"ezibo",
	"created_at":"2009-04-13",
	"data": [
	'table[id="rightAd"]{ display: none !important }'
	]
},
{"name":"ifeng",
	"enabled":"true",
	"url_regexp":/^http:\/\/.*\.ifeng\.com\//,
	"url_example":"http://finance.ifeng.com/money/wealth/staff/20090416/547286.shtml",
	"updated_at":"2009-04-15",
	"created_by":"ezibo",
	"created_at":"2009-04-13",
	"data": [
'div[id="final_navi_top"],[id="final_head_ad"],[id="main_right"],[class="ad_pic"],[class="ad_text"],[id="back"],[id="footer"].mainhead,.boxFoot{ display: none !important }\
div[id^="artical"] {width:950px !important;}'
	]
},
{"name":"QQ",
"enabled":"true",
"url_regexp":/^http:\/\/(?!blog).*\.qq\.com\//,
"url_example":"http://news.qq.com/a/20090403/001139.htm",
"updated_at":"2009-04-24",
"created_by":"deform",
"created_at":"2009-04-24",
"data": [
'.news_ad_box,#cntR,#PicNews,#PicNewsTit,#hotnews,#qq_NavCenter,#nav,#ViewBack,#topAd,#Pfc2,#SosoZone,.area361,.rline,.cntMain .cntL .AdZoneLc,div#ArticleCnt>div#Reading{display: none !important;}\
[id^="AdZone"],[class^="AdZone"],[id^="HotPic"],[id^="HotPic"]{display: none !important;}\
.article_area,.location{width:100% !important;}\
#cntL,#ArticleCnt{width:auto !important;}\
#cntMain{ display:block !important; background-image:none !important;; background-color:#f7fcff !important}'
]
},
{"name":"youku",
	"enabled":"true",
	"url_regexp":/^http:\/\/v\.youku\.com\/v_show\//,
	"created_by":"greenworld",
	"created_at":"2009-04-30",
	"data": [
'#col3.right,.footerBox,.s_header { display: none !important;}\
.videoPlay, .player {height:570px !important;width:930px !important;}\
.left{width:600px !important;}\
.center,.listArea{float:right !important;margin-right:0px !important;margin-top:570px !important;}'
	]
},
{"name":"youku",
	"enabled":"true",
	"url_regexp":/^http:\/\/v\.youku\.com\/v_playlist\//,
	"created_by":"greenworld",
	"created_at":"2009-04-30",
	"data": [
'.footerBox{display: none !important;}\
.listPlay ,.player{height:680px !important;width:930px !important;}\
.right{margin-top:680px !important;}'
]
},
{"name":"chinanews",
	"enabled":"true",
	"url_regexp":/^http:\/\/www.chinanews.com.cn\//,
	"created_by":"deform",
	"created_at":"2009-06-22",
	"data": [
	'.text_right,#all #banner .banner_3, #container #ngg{ display: none !important }\
	#all #text .text_left{width:100% !important;}\
	.left_zw{width:95% !important;}'
	]
},
{"name":"clubchina",
	"enabled":"true",
	"url_regexp":/^http:\/\/(military\.)?club\.china\.com\//,
	"created_by":"deform",
	"created_at":"2009-06-22",
	"data": [
	'.forumSider,.headbanner{display:none !important}',
	'.signContent{display:none !important}',
	'#bodyid #outer #contain-all #forumcontainer .forumBody .forumMain,div.postInfo{width: 100% !important}',
	'.postContentBox{width:90% !important;}'
	]
},
{"name":"hexun",
	"enabled":"true",
	"url_regexp":/^http:\/\/.*hexun\.com\//,
	"url_example":"",
	"created_by":"ezibo",
	"created_at":"2009-05-08",
	"data": [
	'#yued,#flashad,.business,.qz_ad,.link,.copyright{display: none !important;}'
	]
},
{"name":"china",
	"enabled":"true",
	"url_regexp":/^http:\/\/(?!blog)(?!bbs)(?!club).*\.china\.com\//,
	"url_example":"http://military.china.com/zh_cn/important/11052771/20090415/15433154.html",
	"updated_at":"2009-04-02",
	"created_by":"ezibo",
	"created_at":"2009-04-13",
	"data": [
'.huyi,.fullClmAT,.homeheadAT,#chan_mainBlk_rgt,.noPrint,.chan_miscBlk .photo4s,.adclass,#clm01,#EndPageRollText,#ReadingCon,#Reading,[src^="/zh_cn/etc/endpage/img0610/reading.gif"],[src^="/zh_cn/etc/gghead2950.shtml"]{display: none !important }\
#chan_mainBlk,#container{ display:block !important; background-image:none !important;; background-color:#ffffff !important; padding:12px 100px 9px !important }\
#chan_newsDetail,#chan_mainBlk #chan_mainBlk_lft{width:100% !important;}'
	]
},
{"name":"people",
	"enabled":"true",
	"url_regexp":/^http:\/\/.*\.people.com.cn\//,
	"created_by":"deform",
	"created_at":"2009-08-22",
	"data": [
	'div.right_content{display:none !important}',
	'div.left_content>div.left_c_c{display:block !important; background-image:none !important;  padding:12px 182px 120px !important;margin-right:100px !important }',
	'div#p_content,font#zoom.show_c{position:relative!important;padding-left:-100px !important;}',
	]
},
{"name":"sohuclub",
	"enabled":"true",
	"url_regexp":/^http:\/\/(club|bbs).*sohu\.com\//,
	"url_example":"http://club.sports.sohu.com/r-basketball-2260866-0-77-900.html",
	"created_by":"ezibo",
	"created_at":"2009-05-08",
	"data": [
	'[class^="sign"],[class^="ad"],[class^="blank"],#header,#footer{display: none !important;}',
	'EMBED[src^="http://images.sohu.com/bill/"],iframe[src^="http://images.sohu.com/"]{display: none !important;}'
	]
},
{"name":"6cn",
	"enabled":"true",
	"url_regexp":/^http:\/\/6\.cn\/(watch|plist)\//,
	"created_by":"greenworld",
	"data": [
	'[id^="adText"],.column3,#palyerAdText,[id^="ays"] { display: none !important;}',
	'#watchPlayer>#flash_play {height:570px !important;width:930px !important;}',
	'#watchTool {margin-top:190px !important;}',
	'.column2 {margin-top:608px !important;}'
	]
},
{"name":"rayfile",
	"enabled":"true",
	"url_regexp":/^http:\/\/.*rayfile\.com\//,
	"url_example":"http://www.rayfile.com/zh-cn/files/83bd8057-ec8c-11de-8d46-0014221b798a",
	"created_by":"ezibo",
	"data": [
'DIV[id="content"]>DIV[class="nDown_level_0"]:nth-child(6){display: none !important;}',
'DIV[id="nDown_left"]{display: none !important;} ',
'DIV[id="content"]>DIV[class="nDown_level_3"]:nth-child(10){display: none !important;}',
'DIV[id="nDown_level_2"]{display: none !important;}',
'DIV[id="nDown_right"]{width:100% !important;}'
	]
},
{}];
// ==UserScript==
// @name Play high-quality YouTube videos, if they are available.
// @author David Bliss
// @include http://youtube.com/watch?v*
// @include http://www.youtube.com/watch?v*
// ==/UserScript==

if( location.href.indexOf("fmt=") == -1 )
{
	location.href = location.href + "&fmt=18";
}
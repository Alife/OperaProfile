// ==UserScript==

// ==/UserScript==

SWFObject = function($) {
    this.cfg = $;
    this.swfId = $.fid;
    this.asObjects = {};
    this.onLoadInit = null;
    SWFObject.instances[this.swfId] = this
};
SWFObject.prototype.load = function() {
    Utils.f(this.cfg)
};
SWFObject.prototype.getASObject = function($) {
    return this.asObjects[$.asoId]
};
SWFObject.prototype.registerASObject = function(A) {
    var _ = A.asoId,
    $ = this.swfId;
    return this.asObjects[_] = new ASObject({
        asoId: _,
        swfId: $
    })
};
SWFObject.prototype.getASObjectProperty = function($) {
    if (this.swf == null) this.swf = Utils.g(this.swfId);
    return this.swf.getASObjectProperty($)
};
SWFObject.prototype.setASObjectProperty = function($) {
    if (this.swf == null) this.swf = Utils.g(this.swfId);
    this.swf.setASObjectProperty($)
};
SWFObject.prototype.callASObjectMethod = function($) {
    if (this.swf == null) this.swf = Utils.g(this.swfId);
    return this.swf.callASObjectMethod($)
};
SWFObject.instances = {};
SWFObject.getSWFObject = function($) {
    return SWFObject.instances[$.swfId]
};
SWFObject.dispatchASObjectEvent = function(B) {
    var _ = B.swfId,
    A = B.asoId,
    F = B.type,
    E = B.data,
    C = SWFObject.getSWFObject({
        swfId: _
    }),
    $ = (A == undefined) ? C: C.getASObject({
        asoId: A
    }),
    D = "on" + F.substr(0, 1).toUpperCase() + F.substr(1);
    if ($[D] != null) $[D](E)
};
SWFObject.registerASObject = function(A) {
    var $ = A.swfId,
    _ = A.asoId,
    B = SWFObject.getSWFObject(A);
    B.registerASObject(A)
};
ASObject = function($) {
    this.swfId = $.swfId;
    this.asoId = $.asoId;
    this.swfObject = SWFObject.getSWFObject($);
    if (ASObject.instances[this.swfId] == null) ASObject.instances[this.swfId] = {};
    ASObject.instances[this.swfId][this.asoId] = this
};
ASObject.prototype.get = function($) {
    return this.swfObject.getASObjectProperty({
        asoId: this.asoId,
        property: $
    })
};
ASObject.prototype.set = function(_, $) {
    this.swfObject.setASObjectProperty({
        asoId: this.asoId,
        property: _,
        value: $
    })
};
ASObject.prototype.call = function($, _) {
    return this.swfObject.callASObjectMethod({
        asoId: this.asoId,
        method: $,
        parameters: _
    })
};
ASObject.instances = {};
Utils = {
    g: function($) {
        return document.getElementById($)
    },
    f: function(_) {
        var $ = '<embed id="#{fid}" name="#{fid}" src="#{movie}" flashVars="#{flashVars}" width="#{width}" height="#{height}" align="#{align}" type="application/x-shockwave-flash" pluginspage="http://www.adobe.com/go/getflashplayer" wmode="#{wmode}" scale="#{scale}" salign="#{salign}" allownetworking="#{allownetworking}" allowscriptaccess="#{allowscriptaccess}" />',
        A = '<object id="#{fid}" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" width="#{width}" height="#{height}" align="#{align}"><param name="movie" value="#{movie}" /><param name="flashVars" value="#{flashVars}" /><param name="wmode" value="#{wmode}" /><param name="scale" value="#{scale}" /><param name="salign" value="#{salign}" /><param name="allownetworking" value="#{allownetworking}" /><param name="allowscriptaccess" value="#{allowscriptaccess}" /></object>';
        this.g(_.cid).innerHTML = this.fm(this.b.isIE ? A: $, _)
    },
    fm: function($, _) {
        if (arguments.length) if (typeof(_) == "object") $ = $.replace(/#\{([^\{\}]+)\}/g,
        function(A, B) {
            var $ = _[B];
            if (typeof $ == "function") $ = $(B);
            return typeof($) == "undefined" ? "": $
        });
        else if (typeof(_) != "undefined") for (var A = arguments.length - 2; A > -1; A--) $ = $.replace(new RegExp("#\\{" + A + "\\}", "g"), arguments[A + 1]);
        return $
    },
    b: {
        isIE: /msie/i.test(navigator.userAgent),
        isFF: /firefox/i.test(navigator.userAgent),
        isMaxthon: (function() {
            var $ = false;
            try {
                $ = external.max_version
            } catch(_) {}
            return $
        })()
    },
    mo: function() {
        var $ = {},
        B = arguments.length;
        for (var C = 0; C < B; C++) {
            var A = arguments[C];
            for (var _ in A) {
                if ($[_] != null) continue;
                $[_] = arguments[C][_]
            }
        }
        return $
    }
};
HWR = {
    loaded: false
};
HWR.load = function(E, C, D) {
    HWR.tid = C;
    var $ = D ? ("serviceUrl=" + D) : "",
    B = {
        cid: E,
        fid: E + "_flash",
        width: 410,
        height: 290,
        movie: "http://123.baidu.com/swf/main.swf?v=1.1",
        align: "middle",
        salign: "lt",
        wmode: "window",
        scale: "noscale",
        allowscriptaccess: "always",
        allownetworking: "all",
        flashVars: $
    },
    A = new SWFObject(B);
    HWR.so = A;
    var _;
    A.onLoadInit = function($) {
        HWR.ao = _ = A.asObjects.handWrite;
        _.onCloseClick = function($) {
            HWR._onCloseClick()
        };
        _.onCharSelect = function($) {
            HWR._onCharSelect($["char"])
        }
    };
    A.load()
};
HWR._onCharSelect = function(A) {
    var $ = HWR.tid;
   var G = $.selectionStart;
   var H = $.selectionEnd;
   $.value = $.value.substring(0,G) + A + $.value.substring(H,$.value.length);
   $.selectionStart = G + A.length;
   $.selectionEnd = G + A.length;
};
HWR._onCloseClick = function() {
    if (HWR.onCloseClick) HWR.onCloseClick()
};
HWR.onCloseClick = null;
HWR.clear = function() {
    HWR.ao.call("clear", [])
};
function getFlashVersion() {
    var B = navigator;
    if (B.plugins && B.mimeTypes.length) {
        var A = B.plugins["Shockwave Flash"];
        if (A && A.description) return A.description.replace(/([a-zA-Z]|\s)+/, "").replace(/(\s)+r/, ".") + ".0"
    } else if (window.ActiveXObject && !window.opera) for (var C = 10; C >= 2; C--) {
        try {
            var _ = new ActiveXObject("ShockwaveFlash.ShockwaveFlash." + C);
            if (_) {
                return C + ".0.0";
                break
            }
        } catch($) {}
    }
    return "0"
}
function addStyle(A, $) {
    var _ = document.styleSheets[0];
    if (_.addRule) _.addRule(A, $);
    else if (_.insertRule) _.insertRule(A + " { " + $ + " }", _.cssRules.length)
}
function penControl() {
    var $ = parseInt(getFlashVersion());
    if ($ < 9) addStyle("#penControl", "display:none")
}
function stopClosePen($) {
    $ = $ || window.event;
    if ($.stopPropagation) $.stopPropagation();
    else $.cancelBubble = true
}
HWR.onCloseClick = function() {
    HWR.clear();
    var _ = document.getElementById(HWR.so.cfg.cid);
    _.className = "hwr_hidden_ujs";
};
function findPos(obj) {
    var curleft = curtop = 0;
    do {
      curleft += obj.offsetLeft;
      curtop += obj.offsetTop;
    } while (obj = obj.offsetParent);
    return [curleft, curtop];
  }
function scrollDist() {
    var html = document.getElementsByTagName('html')[0];
    if (html.scrollTop && document.documentElement.scrollTop) {
      return [html.scrollLeft, html.scrollTop];
    } else if (html.scrollTop || document.documentElement.scrollTop) {
      return [html.scrollLeft + document.documentElement.scrollLeft, html.scrollTop + document.documentElement.scrollTop];
    } else if (document.body.scrollTop)
      return [document.body.scrollLeft, document.body.scrollTop];
    return [0, 0];
  }
function innerDimensions() {
    if (self.innerHeight) {
      return [self.innerWidth, self.innerHeight];
    } else if (document.documentElement && document.documentElement.clientHeight) {
      return [document.documentElement.clientWidth, document.documentElement.clientHeight];
    } else if (document.body)
      return [document.body.clientWidth, document.body.clientHeight];
    return [0, 0];
  }

document.addEventListener('DOMContentLoaded',
function() {
    hwrcss = '#hwr_div_ujs{position:absolute;}.hwr_hidden_ujs{display:none;}.hwr_visible_ujs{display:block;}';
    var hwrstyle = document.createElement('style');
    hwrstyle.setAttribute('type', 'text/css');
    hwrstyle.textContent = hwrcss;
    document.getElementsByTagName('head')[0].appendChild(hwrstyle);
    hwrdiv = document.createElement('div');
    hwrdiv.id = "hwr_div_ujs";
    hwrdiv.className = "hwr_hidden_ujs";
    document.body.appendChild(hwrdiv);
},
false);

document.documentElement.addEventListener('click',
function(e) {
    if (e.ctrlKey && !e.shiftKey && !e.altKey && (e.target.nodeName == "TEXTAREA" || e.target.type == "text" || e.target.type == "password")) {
        var tPos = findPos(e.target),
        wDim = innerDimensions(),
        sDis = scrollDist();
        if (tPos[1] + 293 + e.target.offsetHeight - sDis[1] - wDim[1] > 0) {
            hwr_div_ujs.style.top = tPos[1] - 293 + "px";
        } else {
            hwr_div_ujs.style.top = tPos[1] + e.target.offsetHeight + 3 + "px";
        }
        hwr_div_ujs.style.left = Math.max(0, Math.min(tPos[0], wDim[0] - 430)) + "px";
        hwr_div_ujs.className = "hwr_visible_ujs";
        penControl();
        HWR.load("hwr_div_ujs", e.target, "http://hw.baidu.com/");
    } else {
        HWR.onCloseClick();
    }
},
false);
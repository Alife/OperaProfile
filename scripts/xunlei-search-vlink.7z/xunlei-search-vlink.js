// ==UserScript==
// @name Gougou Link Revealer
// @author somh
// @email ahmore@gmail.com
// @include http://*/dload1.html?cid=*
// @include http://pub.xunlei.com/fcg-bin/cgi_download.fcg?cid=*
// @include http://*down?cid=*
// @include http://*down1?cid=*
// @include http://www.gougou.com/search*
// @ujs:modified 1:26 2009-4-15
// ==/UserScript==

/*
if( location.href.indexOf('down1?cid=')>1 ) {
	window.opera.addEventListener('BeforeEvent.load',function (e) {
		e.preventDefault();
		location.replace(location.href.replace(/down1\?/i,"down?"));
	},false);
}

if( location.href.indexOf('www.gougou.com/search')>1 ) {
	window.addEventListener('DOMContentLoaded',function (e) {
		var es = document.selectNodes('//a[@onmousedown]');
		for(var i=0, o; o=es[i]; i++){o.href=o.href.replace(/down1\?/i,"down?");}
	},false);
}
*/

window.opera.addEventListener('BeforeScript',function (e) {
	e.preventDefault();
},false);

window.addEventListener('DOMContentLoaded',function (e) {
	e.preventDefault();
	var u=getValue(document.body.parentNode.outerHTML,'var furlArr=["','"];');
	var dWrap=document.createElement("div");
	var dText=document.createElement("div");
	dWrap.style="margin:10% 15% 5px; padding:16px;overflow:hidden;text-align:center;font:9pt Candara;background:-o-skin(\"Secure Popup Header Skin\")";
	dWrap.id="thunder";
	if(u!=""){
		var ltitle=(u.replace(/.*\//ig,'')!='')?u.replace(/.*\//ig,''):u;
		var dAchr=document.getElementById("id0");
		var title=document.title?document.title:dAchr?dAchr.innerText:'';
		var t= "<div style='display:inline-block;margin-right:5px;width:-o-skin;height:-o-skin;background:-o-skin(\"Edit Properties\") no-repeat;'></div>"
		t += title + "<br><br><a style='height:-o-skin;display:inline-block;vertical-align: middle;font:bold 8pt candara,tahoma' href='" + u + "'>" + ltitle + "</a>";
		dWrap.innerHTML=t;
		dText.id="dText";
		dText.type="text";
		dText.style="margin:0 15% 0; border:1px solid #eee;padding:5px;background:#fafafa;text-align:center;display:block;";
		dText.innerText=u;
	}else{
		var es=dArea.selectNodes("//a[@href]");
		for(i=0;i<es.length;i++){
			if(es[i].href.indexOf('ed2k://')>-1){
				es[i].style="display:block;text-align:left;";
				es[i].innerHTML=es[i].innerText;
				dWrap.appendChild(es[i]);
			}
		}
	}
	with(top.document.body){
		innerHTML="";
		appendChild(dWrap);
		style="overflow:hidden";
		appendChild(dText);
	}
	
	function getValue(text, start, end) {
		var p1 = text.indexOf(start);
		if(p1 == -1) return '';
			p1 += start.length;
			var p2 = text.indexOf(end, p1);
		if(p2 == -1) return '';
			return text.substring(p1, p2);
	}
},false);





